package com.voxaz.studio

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/** Understands the different shapes of YouTube links. */
object YouTubeLink {
    private val idRegex = Regex("^[A-Za-z0-9_-]{6,20}$")

    private fun host(u: Uri): String? =
        u.host?.lowercase()?.removePrefix("www.")?.removePrefix("m.")?.removePrefix("music.")

    fun isYouTube(u: Uri): Boolean {
        val h = host(u) ?: return false
        return h == "youtu.be" || h == "youtube.com" || h == "youtube-nocookie.com"
    }

    /** Returns (videoId, playlistId) when the link is a playable video / playlist, else null. */
    fun parse(u: Uri): Pair<String?, String?>? {
        if (!isYouTube(u)) return null
        val h = host(u)
        val seg = u.pathSegments
        val id: String? = if (h == "youtu.be") {
            seg.firstOrNull()
        } else if (u.path == "/watch") {
            u.getQueryParameter("v")
        } else if (seg.firstOrNull() in setOf("shorts", "embed", "live", "v")) {
            seg.getOrNull(1)
        } else null
        val list = u.getQueryParameter("list")?.takeIf { idRegex.matches(it) }
        val vid = id?.takeIf { idRegex.matches(it) }
        if (vid == null && list == null) return null
        return vid to list
    }
}

/**
 * Plays a YouTube link with YouTube's official embedded player.
 * (YouTube streams cannot be played directly by ExoPlayer.)
 */
class YouTubeActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("id")
        val list = intent.getStringExtra("list")
        if (id == null && list == null) {
            finish()
            return
        }
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        root.addView(web, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.cacheMode = WebSettings.LOAD_DEFAULT

        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customCallback = callback
                web.visibility = View.GONE
                root.addView(view, FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                setBars(false)
            }

            override fun onHideCustomView() {
                leaveFullscreen()
            }
        }

        // YouTube only accepts embeds that identify the app (HTTP Referer / origin).
        val origin = "https://" + packageName.lowercase()
        val src = if (id != null) {
            "https://www.youtube.com/embed/$id?autoplay=1&playsinline=1&rel=0&fs=1" +
                (if (list != null) "&list=$list" else "") + "&origin=$origin"
        } else {
            "https://www.youtube.com/embed/videoseries?list=$list&autoplay=1&playsinline=1&rel=0&fs=1&origin=$origin"
        }
        val html = "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>" +
            "<style>html,body{margin:0;height:100%;background:#000}iframe{position:absolute;inset:0;width:100%;height:100%;border:0}</style>" +
            "</head><body><iframe src='$src' referrerpolicy='strict-origin-when-cross-origin' " +
            "allow='autoplay; encrypted-media; picture-in-picture; fullscreen' allowfullscreen></iframe></body></html>"
        web.loadDataWithBaseURL(origin, html, "text/html", "utf-8", null)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customView != null) leaveFullscreen() else finish()
            }
        })
    }

    private fun leaveFullscreen() {
        val v = customView ?: return
        root.removeView(v)
        customView = null
        customCallback?.onCustomViewHidden()
        customCallback = null
        web.visibility = View.VISIBLE
        setBars(true)
    }

    private fun setBars(show: Boolean) {
        WindowCompat.setDecorFitsSystemWindows(window, show)
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (show) {
            c.show(WindowInsetsCompat.Type.systemBars())
        } else {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onPause() {
        super.onPause()
        if (::web.isInitialized) web.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.onResume()
    }

    override fun onDestroy() {
        if (::web.isInitialized) {
            (web.parent as? ViewGroup)?.removeView(web)
            web.destroy()
        }
        super.onDestroy()
    }
}
