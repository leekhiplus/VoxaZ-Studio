package com.voxaz.studio

import java.net.HttpURLConnection
import java.net.URI
import java.net.URL

/** Minimal M3U / M3U8 helper: channel lists (IPTV style) and detection of real HLS playlists. */
object M3u {
    data class Entry(val title: String, val url: String)

    /** True for HLS manifests (they must be played directly by the player, not split into entries). */
    fun isHls(text: String): Boolean = text.contains("#EXT-X-")

    fun parse(text: String, base: String?): List<Entry> {
        val out = ArrayList<Entry>()
        var title: String? = null
        val nameAttr = Regex("tvg-name=\"([^\"]*)\"")
        for (raw in text.lineSequence()) {
            val line = raw.trim().removePrefix("\uFEFF")
            if (line.isEmpty()) continue
            if (line.startsWith("#EXTINF", ignoreCase = true)) {
                var t = line.substringAfter(',', "").trim()
                if (t.isEmpty()) t = nameAttr.find(line)?.groupValues?.get(1)?.trim() ?: ""
                title = t.ifEmpty { null }
            } else if (line.startsWith("#")) {
                continue
            } else {
                val url = resolve(line, base)
                val fallback = line.substringBefore('?').substringAfterLast('/').ifEmpty { url }
                out.add(Entry(title ?: fallback, url))
                title = null
            }
        }
        return out
    }

    private fun resolve(line: String, base: String?): String {
        if (line.contains("://") || base == null) return line
        return runCatching { URI(base).resolve(line).toString() }.getOrDefault(line)
    }

    /** Downloads a playlist (max 8 MB). Call from a background thread. */
    fun fetch(url: String): String? = runCatching {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 15_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) Zarvimo")
        c.inputStream.use { readLimited(it) }
    }.getOrNull()

    fun readLimited(input: java.io.InputStream, max: Int = 8 * 1024 * 1024): String {
        val buf = java.io.ByteArrayOutputStream()
        val tmp = ByteArray(16 * 1024)
        while (buf.size() < max) {
            val n = input.read(tmp)
            if (n < 0) break
            buf.write(tmp, 0, n)
        }
        return buf.toString("UTF-8")
    }
}
