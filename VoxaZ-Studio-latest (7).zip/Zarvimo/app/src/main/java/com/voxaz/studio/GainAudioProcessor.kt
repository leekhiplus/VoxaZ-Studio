package com.voxaz.studio

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer

/**
 * Software volume boost applied to the decoded PCM audio itself, so it works on every phone
 * (the system LoudnessEnhancer effect is ignored by many devices).
 * gain 1.0 = unchanged. Loud peaks are soft-limited instead of hard-clipped to avoid harsh distortion.
 */
@OptIn(UnstableApi::class)
class GainAudioProcessor : BaseAudioProcessor() {

    @Volatile
    var gain: Float = 1f

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        return if (inputAudioFormat.encoding == C.ENCODING_PCM_16BIT ||
            inputAudioFormat.encoding == C.ENCODING_PCM_FLOAT
        ) inputAudioFormat else AudioProcessor.AudioFormat.NOT_SET
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val out = replaceOutputBuffer(size)
        val g = gain
        val is16 = inputAudioFormat.encoding == C.ENCODING_PCM_16BIT
        if (g == 1f) {
            out.put(inputBuffer)
        } else if (is16) {
            while (inputBuffer.remaining() >= 2) {
                val s = inputBuffer.short / 32768f
                out.putShort((soft(s * g) * 32767f).toInt().toShort())
            }
        } else {
            while (inputBuffer.remaining() >= 4) {
                out.putFloat(soft(inputBuffer.float * g))
            }
        }
        out.flip()
    }

    /** Linear below 0.7, smoothly compressed towards +-1.0 above it. */
    private fun soft(x: Float): Float {
        val a = if (x < 0f) -x else x
        if (a <= 0.7f) return x
        val t = (a - 0.7f) / 0.3f
        val y = 0.7f + 0.3f * (t / (1f + t))
        return if (x < 0f) -y else y
    }
}
