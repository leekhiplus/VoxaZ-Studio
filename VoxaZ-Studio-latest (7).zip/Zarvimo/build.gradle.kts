buildscript {
    repositories { google(); mavenCentral() }
    dependencies {
        // AGP 9 has built-in Kotlin; this pins the Kotlin Gradle plugin to the latest stable
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:2.4.20")
    }
}

plugins {
    id("com.android.application") version "9.3.3" apply false
}
