package com.voxaz.studio

import android.app.Activity
import android.os.SystemClock
import android.view.View
import android.widget.FrameLayout
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform

/**
 * AdMob wrapper: user consent (UMP), one adaptive banner and one interstitial.
 * Debug builds use Google's test ad units, release builds use the real ones (see build.gradle.kts).
 */
class AdsManager(private val activity: Activity) {

    private val consent: ConsentInformation = UserMessagingPlatform.getConsentInformation(activity)
    private var initialized = false
    private var interstitial: InterstitialAd? = null
    private var loading = false
    private var lastShownAt = 0L
    private var banner: AdView? = null
    private var container: FrameLayout? = null

    /** Turned off while the child lock is on: no ads, so nothing can lead out of the app. */
    var enabled = true
        set(value) {
            field = value
            if (value) showBannerIfPossible() else detachBanner()
        }

    /** Ask for consent where required (EEA/UK), then start the ads SDK. */
    fun start() {
        val params = ConsentRequestParameters.Builder().build()
        consent.requestConsentInfoUpdate(
            activity,
            params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) {
                    initIfAllowed()
                }
            },
            {
                initIfAllowed()
            }
        )
        initIfAllowed()
    }

    private fun initIfAllowed() {
        if (initialized || !consent.canRequestAds()) return
        initialized = true
        Thread {
            MobileAds.initialize(activity) {
                activity.runOnUiThread {
                    loadInterstitial()
                    showBannerIfPossible()
                }
            }
        }.start()
    }

    fun privacyOptionsRequired(): Boolean =
        consent.privacyOptionsRequirementStatus == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED

    fun showPrivacyOptions() {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { }
    }

    // ---------------- banner ----------------

    fun attachBanner(target: FrameLayout) {
        detachBanner()
        container = target
        showBannerIfPossible()
    }

    private fun showBannerIfPossible() {
        val target = container ?: return
        if (!enabled || !initialized || banner != null) return
        val dm = activity.resources.displayMetrics
        val widthPx = if (target.width > 0) target.width else dm.widthPixels
        val widthDp = (widthPx / dm.density).toInt()
        val view = AdView(activity)
        view.adUnitId = BuildConfig.ADMOB_BANNER
        view.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, widthDp))
        view.adListener = object : AdListener() {
            override fun onAdLoaded() {
                target.visibility = View.VISIBLE
            }

            override fun onAdFailedToLoad(error: LoadAdError) {
                target.visibility = View.GONE
            }
        }
        target.removeAllViews()
        target.addView(view)
        banner = view
        view.loadAd(AdRequest.Builder().build())
    }

    fun detachBanner() {
        banner?.destroy()
        banner = null
        container?.let {
            it.removeAllViews()
            it.visibility = View.GONE
        }
    }

    fun pause() {
        banner?.pause()
    }

    fun resume() {
        banner?.resume()
    }

    fun destroy() {
        detachBanner()
        interstitial = null
    }

    // ---------------- interstitial ----------------

    private fun loadInterstitial() {
        if (!initialized || interstitial != null || loading) return
        loading = true
        InterstitialAd.load(
            activity,
            BuildConfig.ADMOB_INTERSTITIAL,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitial = ad
                    loading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitial = null
                    loading = false
                }
            }
        )
    }

    /** Show an interstitial if one is ready and the cooldown has passed; always calls [after] afterwards. */
    fun showInterstitial(minGapMs: Long = 90_000L, after: () -> Unit) {
        val ad = interstitial
        val now = SystemClock.elapsedRealtime()
        if (!enabled || ad == null || now - lastShownAt < minGapMs) {
            loadInterstitial()
            after()
            return
        }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                interstitial = null
                lastShownAt = SystemClock.elapsedRealtime()
                loadInterstitial()
                after()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                interstitial = null
                loadInterstitial()
                after()
            }
        }
        ad.show(activity)
    }
}
