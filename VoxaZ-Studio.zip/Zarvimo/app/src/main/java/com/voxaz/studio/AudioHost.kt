package com.voxaz.studio

import android.content.ComponentName
import android.content.Context
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

/** Connects the UI to [PlaybackService] through a MediaController. */
class AudioHost(private val context: Context, private val onChange: () -> Unit) {

    var controller: MediaController? = null
        private set
    private var future: ListenableFuture<MediaController>? = null
    private val pending = ArrayList<(MediaController) -> Unit>()

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            onChange()
        }
    }

    fun hasMedia(): Boolean = (controller?.mediaItemCount ?: 0) > 0

    /** Runs [whenReady] as soon as the controller is connected. */
    fun connect(whenReady: (MediaController) -> Unit) {
        val c = controller
        if (c != null) {
            whenReady(c)
            return
        }
        pending.add(whenReady)
        if (future != null) return
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val f = MediaController.Builder(context, token).buildAsync()
        future = f
        f.addListener({
            val ctl = runCatching { f.get() }.getOrNull()
            if (ctl != null) {
                controller = ctl
                ctl.addListener(listener)
                val todo = ArrayList(pending)
                pending.clear()
                todo.forEach { it(ctl) }
            } else {
                pending.clear()
                future = null
            }
            onChange()
        }, ContextCompat.getMainExecutor(context))
    }

    fun release() {
        controller?.removeListener(listener)
        future?.let { MediaController.releaseFuture(it) }
        controller = null
        future = null
        pending.clear()
    }
}
