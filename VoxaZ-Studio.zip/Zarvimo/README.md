# Zarvimo

Media3 (ExoPlayer) پر مبنی اینڈرائیڈ ویڈیو پلیئر۔

## APK بنانے کا طریقہ (زپ extract کیے بغیر)
1. GitHub پر نیا repo بنائیں۔
2. **Add file → Upload files** سے `VoxaZ-Studio.zip` جوں کی توں اپلوڈ کریں اور Commit کریں۔
3. **Add file → Create new file** میں نام `.github/workflows/build.yml` لکھیں، `build.yml` کا مواد پیسٹ کریں اور Commit کریں (صرف ایک بار)۔
4. **Actions** میں بلڈ خود شروع ہوگا۔ ورک فلو زپ خود unzip کرتا ہے۔
5. مکمل ہونے پر repo کے **Releases** سیکشن سے `VoxaZ-Studio.apk` سیدھی ڈاؤنلوڈ کریں۔

## فیچرز
- لینڈ اسکیپ: بائیں سائیڈ بار، درمیان میں پلیئر، دائیں طرف Now Playing۔ پورٹریٹ: نیچے نیویگیشن بار، اوپر 16:9 پلیئر (عمودی ویڈیو بھی اسی خانے میں)، نیچے قطار
- Shorts: ٹک ٹاک کی طرح اوپر نیچے اسکرول، ساری شارٹس ایک فیڈ میں، لوپ، ٹیپ سے پاز، دل کا بٹن (Favorites)
- Library میں صرف ایک منٹ سے لمبی ویڈیوز، Shorts میں ایک منٹ یا کم (حد Settings میں بدلی جا سکتی ہے)
- Settings ٹیب: AMOLED فلٹر، اسکرین اورینٹیشن، ڈیفالٹ اسپیڈ، ایسپیکٹ ریشو، ڈبل ٹیپ سیک، ریزیوم، جیسچرز، Shorts کی حد، ہسٹری صاف
- روٹیٹ بٹن (لائبریری، پلیئر اور Shorts میں) اور Settings میں اورینٹیشن آپشن
- ایکسٹرا والیم: 0 سے 200% تک (100% کے بعد LoudnessEnhancer)، سلائیڈر اور سوائپ جیسچر دونوں سے
- Video info: Settings میں اور ویڈیو پر لانگ پریس سے مکمل تفصیل (کوڈیک، ریزولوشن، فریم ریٹ، بٹ ریٹ، آڈیو، HDR، پاتھ وغیرہ) اور Copy بٹن
- Shorts چائلڈ لاک: PIN کے ساتھ، لاک میں صرف اسکرولنگ، بیک / نیویگیشن / لائک / روٹیٹ بند، ایپ دوبارہ کھلنے پر بھی لاک رہتا ہے
- اسموتھ اینیمیشنز: پین فیڈ / سلائیڈ، بٹن پریس، لسٹ انٹری، Shorts پیج ٹرانزیشن، دل / پاز آئیکن، سیک بار (Settings میں Animations آن/آف)
- About & Legal: Settings میں About، Privacy Policy، Terms of Use، Open-source licenses، Contact support (assets/legal میں HTML صفحات؛ developer_name اور support_email strings.xml میں بدلیں)
- Music: آڈیو لائبریری، Now Playing اسکرین، بیک گراؤنڈ پلے نوٹیفکیشن کے ساتھ، شفل، ریپیٹ، سلیپ ٹائمر (PlaybackService + AudioHost)
- AdMob: Banner (لائبریری کے نیچے) اور Interstitial (ہر 3 ویڈیوز / ہر 6 شارٹس)، debug بلڈ میں ٹیسٹ ایڈز، release میں اصلی؛ UMP consent؛ چائلڈ لاک میں اشتہارات بند
- ہلکا AMOLED اسٹائل کلر گریڈ (✨ بٹن: Natural / AMOLED Soft / AMOLED Rich)
- Folders، Favorites، History، Playlist (ویڈیو پر لانگ پریس)، سرچ، گرڈ / لسٹ
- کنٹرولز: 10 سیکنڈ پیچھے / 30 آگے، اگلی / پچھلی، والیوم، اسپیڈ، سب ٹائٹل، آڈیو ٹریک، فل اسکرین، PiP، اسکرین لاک
- نیٹ ورک لنک (MP4 / HLS / DASH)، آخری پوزیشن سے دوبارہ چلانا، "Open with"
