package com.voxaz.studio

import android.content.Context
import android.net.Uri
import java.util.Locale

data class VideoItem(
    val uri: Uri,
    val title: String,
    val durationMs: Long = 0,
    val size: Long = 0,
    val folder: String = ""
)

fun fmt(ms: Long): String {
    val s = ms.coerceAtLeast(0) / 1000
    val h = s / 3600
    val m = s % 3600 / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%02d:%02d", m, sec)
}

/** Favorites, playlist, history and resume positions (SharedPreferences). */
class Store(context: Context) {
    private val sp = context.getSharedPreferences("voxaz", Context.MODE_PRIVATE)

    private fun read(key: String): MutableList<String> =
        (sp.getString(key, "") ?: "").split("\n").filter { it.isNotEmpty() }.toMutableList()

    private fun write(key: String, values: List<String>) {
        sp.edit().putString(key, values.joinToString("\n")).apply()
    }

    private fun toggle(key: String, u: String): Boolean {
        val l = read(key)
        val added = if (l.contains(u)) {
            l.remove(u)
            false
        } else {
            l.add(0, u)
            true
        }
        write(key, l)
        return added
    }

    fun favorites(): List<String> = read("fav")
    fun playlist(): List<String> = read("pl")
    fun history(): List<String> = read("hist")
    fun isFav(u: String): Boolean = read("fav").contains(u)
    fun inPlaylist(u: String): Boolean = read("pl").contains(u)
    fun toggleFav(u: String): Boolean = toggle("fav", u)
    fun togglePlaylist(u: String): Boolean = toggle("pl", u)

    fun addHistory(u: String) {
        val l = read("hist")
        l.remove(u)
        l.add(0, u)
        write("hist", l.take(50))
    }

    /** Display enhancement: 0 off, 1 soft AMOLED, 2 rich AMOLED. */
    fun fx(): Int = sp.getInt("fx", 1)

    fun setFx(v: Int) {
        sp.edit().putInt("fx", v).apply()
    }

    fun readInt(key: String, def: Int): Int = sp.getInt(key, def)

    fun putInt(key: String, v: Int) {
        sp.edit().putInt(key, v).apply()
    }

    fun readBool(key: String, def: Boolean): Boolean = sp.getBoolean(key, def)

    fun putBool(key: String, v: Boolean) {
        sp.edit().putBoolean(key, v).apply()
    }

    fun clearHistory() {
        sp.edit().remove("hist").apply()
    }

    fun getPos(u: String): Long = sp.getLong("pos_$u", 0L)

    fun setPos(u: String, p: Long) {
        sp.edit().putLong("pos_$u", p).apply()
    }
}
