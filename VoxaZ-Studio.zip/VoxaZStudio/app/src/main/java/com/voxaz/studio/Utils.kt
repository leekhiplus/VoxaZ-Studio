package com.voxaz.studio

import android.net.Uri
import java.util.Locale

data class VideoItem(
    val uri: Uri,
    val title: String,
    val durationMs: Long = 0,
    val size: Long = 0
)

/** Playlist handed from the library screen to the player. */
object Playlist {
    var items: List<VideoItem> = emptyList()
}

fun fmt(ms: Long): String {
    val s = ms.coerceAtLeast(0) / 1000
    val h = s / 3600
    val m = s % 3600 / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%02d:%02d", m, sec)
}
