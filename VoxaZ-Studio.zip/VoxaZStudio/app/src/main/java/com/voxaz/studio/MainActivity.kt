package com.voxaz.studio

import android.Manifest
import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.media.AudioManager
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.InputFilter
import android.text.InputType
import android.text.format.Formatter
import android.util.Rational
import android.util.TypedValue
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.AnimationUtils
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.widget.doAfterTextChanged
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.roundToInt

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    private enum class Section { LIBRARY, SHORTS, PLAYLIST, FOLDERS, FAVORITES, HISTORY, SETTINGS }

    private lateinit var store: Store
    private lateinit var audio: AudioManager
    private lateinit var videoAdapter: VideoAdapter
    private lateinit var folderAdapter: FolderAdapter
    private lateinit var queueAdapter: QueueAdapter
    private lateinit var shortsAdapter: ShortsAdapter
    private val handler = Handler(Looper.getMainLooper())

    // ---- views (re-bound whenever the layout is rebuilt, e.g. on rotation) ----
    private lateinit var root: View
    private lateinit var sidebar: View
    private lateinit var miniCard: View
    private lateinit var miniThumb: ImageView
    private lateinit var miniName: TextView
    private lateinit var miniMeta: TextView
    private lateinit var libraryPane: View
    private lateinit var playerPane: View
    private lateinit var shortsPane: View
    private lateinit var shortsPager: ViewPager2
    private lateinit var shortsEmpty: TextView
    private lateinit var btnChildLock: ImageView
    private lateinit var btnRotateShorts: View
    private lateinit var settingsPane: View
    private lateinit var settingsList: LinearLayout
    private lateinit var sectionTitle: TextView
    private lateinit var search: EditText
    private lateinit var btnGrid: ImageView
    private lateinit var btnList: ImageView
    private lateinit var recycler: RecyclerView
    private lateinit var emptyView: TextView
    private lateinit var topBar: View
    private lateinit var tvTitle: TextView
    private lateinit var btnAspect: TextView
    private lateinit var btnFx: ImageView
    private lateinit var playerView: PlayerView
    private lateinit var videoArea: View
    private lateinit var info: TextView
    private lateinit var controls: View
    private lateinit var tvPos: TextView
    private lateinit var tvDur: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var volSeek: SeekBar
    private lateinit var btnPlay: ImageView
    private lateinit var btnSpeed: TextView
    private lateinit var btnLock: View
    private lateinit var btnUnlock: View
    private lateinit var queuePanel: View
    private lateinit var queueList: RecyclerView
    private lateinit var navItems: Map<Section, TextView>

    // ---- state ----
    private val allVideos = mutableListOf<VideoItem>()
    private var shown: List<VideoItem> = emptyList()
    private var section = Section.LIBRARY
    private var folderFilter: String? = null
    private var gridMode = true
    private var query = ""
    private var denied = false

    private var queue: List<VideoItem> = emptyList()
    private var queueIndex = 0
    private var queueIsShorts = false
    private var shortsIndex = 0
    private var player: ExoPlayer? = null
    private var enhancer: LoudnessEnhancer? = null
    private var playerShown = false
    private var shortsShown = false
    private var settingsShown = false
    private var fullscreen = false
    private var inPip = false
    private var locked = false
    private var controlsShown = true
    private var queueShown = true
    private var seeking = false
    private var videoVertical = false
    private var retried = false
    private var boostPct = 100
    private var childLocked = false
    private var animOn = true
    private var animateNext = false
    private var skipAnim = false
    private var infoText = ""
    private var lastOrientation = Configuration.ORIENTATION_UNDEFINED

    // ---- user settings (persisted) ----
    private var fxMode = 1
    private var orientationMode = 0
    private var speedIdx = 2
    private var resizeIdx = 0
    private var dtapSec = 10
    private var resumeOn = true
    private var gesturesOn = true

    private val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    )
    private val resizeNames = arrayOf("FIT", "FILL", "ZOOM")
    private val fxNames = arrayOf("Natural", "AMOLED Soft", "AMOLED Rich")
    private val orientNames = arrayOf("Auto", "Portrait", "Landscape")

    private val hideInfo = Runnable {
        info.animate().cancel()
        if (animOn) {
            info.animate().alpha(0f).setDuration(200).withEndAction {
                info.visibility = View.GONE
                info.alpha = 1f
            }.start()
        } else {
            info.visibility = View.GONE
        }
    }
    private val hideControls = Runnable {
        if (fullscreen && !seeking) {
            controlsShown = false
            applyLayout()
        }
    }
    private val ticker = object : Runnable {
        override fun run() {
            val p = player
            if (p != null) {
                val dur = p.duration
                val pos = p.currentPosition
                if (shortsShown && !playerShown) {
                    if (dur > 0) shortsAdapter.setProgress((pos * 1000 / dur).toInt())
                } else {
                    if (!seeking) tvPos.text = fmt(pos)
                    if (dur > 0) {
                        tvDur.text = fmt(dur)
                        if (!seeking) seekBar.setProgress((pos * 1000 / dur).toInt(), true)
                    }
                    seekBar.secondaryProgress = p.bufferedPercentage * 10
                }
            }
            handler.postDelayed(this, 500)
        }
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                loadVideos()
            } else {
                denied = true
                refreshList()
            }
        }

    private val pickLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) playUri(uri)
        }

    private val playerListener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val p = player
            if (p != null && !(shortsShown && !playerShown)) onItemChanged(p.currentMediaItemIndex)
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            btnPlay.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
            if (animOn) {
                btnPlay.animate().cancel()
                btnPlay.animate().scaleX(0.8f).scaleY(0.8f).setDuration(70).withEndAction {
                    btnPlay.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
                }.start()
            }
            if (isPlaying) {
                retried = false
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                scheduleHideControls()
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
            if (shortsShown && !playerShown) shortsAdapter.setPaused(!playWhenReady)
        }

        override fun onRenderedFirstFrame() {
            if (shortsShown && !playerShown) shortsAdapter.onFirstFrame()
        }

        override fun onAudioSessionIdChanged(audioSessionId: Int) {
            attachEnhancer(audioSessionId)
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            videoVertical = videoSize.height > videoSize.width && videoSize.width > 0
            updateMini()
        }

        override fun onPlayerError(error: PlaybackException) {
            if (!retried && player != null) {
                // Decoder / codec trouble: rebuild the player once and resume.
                retried = true
                handler.post {
                    releasePlayer()
                    initPlayer()
                }
                return
            }
            Toast.makeText(
                this@MainActivity,
                getString(R.string.play_error, error.errorCodeName),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    // =====================================================================
    // Lifecycle
    // =====================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        audio = getSystemService(AUDIO_SERVICE) as AudioManager

        fxMode = store.fx()
        orientationMode = store.readInt("orient", 0)
        speedIdx = store.readInt("speed", 2).coerceIn(0, speeds.size - 1)
        resizeIdx = store.readInt("aspect", 0).coerceIn(0, resizeModes.size - 1)
        dtapSec = store.readInt("dtap", 10)
        resumeOn = store.readBool("resume", true)
        gesturesOn = store.readBool("gestures", true)
        animOn = store.readBool("anim", true)
        applyOrientation()
        lastOrientation = resources.configuration.orientation
        queueShown = defaultQueueShown()

        videoAdapter = VideoAdapter(
            onClick = { _, pos -> playQueue(shown, pos) },
            onLong = { item, anchor -> showItemMenu(item, anchor) }
        )
        folderAdapter = FolderAdapter { name ->
            folderFilter = name
            refreshList()
        }
        queueAdapter = QueueAdapter { index -> player?.seekTo(index, 0L) }
        shortsAdapter = ShortsAdapter(
            onTap = {
                val p = player
                if (p != null) p.playWhenReady = !p.playWhenReady
            },
            onFav = { item -> store.toggleFav(item.uri.toString()) },
            isFav = { item -> store.isFav(item.uri.toString()) }
        )
        shortsAdapter.fx = { pv -> applyFxTo(pv) }
        shortsAdapter.animations = animOn
        childLocked = store.readBool("childlock", false)
        if (childLocked) {
            section = Section.SHORTS
            shortsShown = true
            shortsAdapter.applyLock(true)
        }

        buildUi()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                handleBack()
            }
        })
        requestAndLoad()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        if (playerShown || shortsShown) initPlayer()
    }

    override fun onResume() {
        super.onResume()
        syncVolume()
        if (childLocked) runCatching { startLockTask() }
    }

    override fun onStop() {
        super.onStop()
        releasePlayer()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        Glide.get(this).trimMemory(level)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (playerShown && player?.isPlaying == true && !locked) enterPip()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (inPip || isInPictureInPictureMode) return
        if (newConfig.orientation != lastOrientation) {
            lastOrientation = newConfig.orientation
            queueShown = defaultQueueShown()
            buildUi()
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean, newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        if (!isInPictureInPictureMode && resources.configuration.orientation != lastOrientation) {
            lastOrientation = resources.configuration.orientation
            queueShown = defaultQueueShown()
            buildUi()
        } else {
            applyLayout()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) updateSystemBars()
    }

    private fun isPortrait(): Boolean =
        resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT

    private fun defaultQueueShown(): Boolean =
        isPortrait() || resources.configuration.screenWidthDp >= 900

    private fun shortMs(): Long = store.readInt("short", 60) * 1000L

    private fun updateSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (childLocked || fullscreen || inPip || !isPortrait()) {
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    private fun applyOrientation() {
        requestedOrientation = when {
            fullscreen && !videoVertical -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            orientationMode == 1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            orientationMode == 2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    private fun toggleOrientation() {
        if (childLocked) return
        orientationMode = if (isPortrait()) 2 else 1
        store.putInt("orient", orientationMode)
        applyOrientation()
        if (settingsShown) renderSettings()
    }

    private fun handleBack() {
        when {
            childLocked -> {}
            locked -> {}
            fullscreen -> setFullscreen(false)
            playerShown -> closePlayerPane()
            shortsShown || settingsShown -> showSection(Section.LIBRARY)
            section == Section.FOLDERS && folderFilter != null -> {
                folderFilter = null
                refreshList()
            }
            else -> finish()
        }
    }

    private fun handleIntent(i: Intent?) {
        if (childLocked) return
        val d = i?.data ?: return
        if (i?.action != Intent.ACTION_VIEW) return
        playUri(d)
    }

    // =====================================================================
    // UI construction (re-run on rotation)
    // =====================================================================

    private fun bindViews() {
        root = findViewById(R.id.root)
        sidebar = findViewById(R.id.sidebar)
        miniCard = findViewById(R.id.miniCard)
        miniThumb = findViewById(R.id.miniThumb)
        miniName = findViewById(R.id.miniName)
        miniMeta = findViewById(R.id.miniMeta)
        libraryPane = findViewById(R.id.libraryPane)
        playerPane = findViewById(R.id.playerPane)
        shortsPane = findViewById(R.id.shortsPane)
        shortsPager = findViewById(R.id.shortsPager)
        shortsEmpty = findViewById(R.id.shortsEmpty)
        btnChildLock = findViewById(R.id.btnChildLock)
        btnRotateShorts = findViewById(R.id.btnRotateShorts)
        settingsPane = findViewById(R.id.settingsPane)
        settingsList = findViewById(R.id.settingsList)
        sectionTitle = findViewById(R.id.sectionTitle)
        search = findViewById(R.id.search)
        btnGrid = findViewById(R.id.btnGrid)
        btnList = findViewById(R.id.btnList)
        recycler = findViewById(R.id.list)
        emptyView = findViewById(R.id.empty)
        topBar = findViewById(R.id.topBar)
        tvTitle = findViewById(R.id.tvTitle)
        btnAspect = findViewById(R.id.btnAspect)
        btnFx = findViewById(R.id.btnFx)
        playerView = findViewById(R.id.player)
        videoArea = findViewById(R.id.videoArea)
        info = findViewById(R.id.info)
        controls = findViewById(R.id.controls)
        tvPos = findViewById(R.id.tvPos)
        tvDur = findViewById(R.id.tvDur)
        seekBar = findViewById(R.id.seek)
        volSeek = findViewById(R.id.volSeek)
        btnPlay = findViewById(R.id.btnPlay)
        btnSpeed = findViewById(R.id.btnSpeed)
        btnLock = findViewById(R.id.btnLock)
        btnUnlock = findViewById(R.id.btnUnlock)
        queuePanel = findViewById(R.id.queuePanel)
        queueList = findViewById(R.id.queueList)
        navItems = mapOf(
            Section.LIBRARY to findViewById<TextView>(R.id.navLibrary),
            Section.SHORTS to findViewById<TextView>(R.id.navShorts),
            Section.PLAYLIST to findViewById<TextView>(R.id.navPlaylist),
            Section.FOLDERS to findViewById<TextView>(R.id.navFolders),
            Section.FAVORITES to findViewById<TextView>(R.id.navFavorites),
            Section.HISTORY to findViewById<TextView>(R.id.navHistory),
            Section.SETTINGS to findViewById<TextView>(R.id.navSettings)
        )
    }

    private fun buildUi() {
        // let go of the old view tree (rotation) before inflating the new one
        if (::playerView.isInitialized) playerView.player = null
        shortsAdapter.reset()

        setContentView(R.layout.activity_main)
        bindViews()
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        setupNav()
        setupLibrary()
        setupPlayerUi()
        setupShorts()
        setupGestures()
        applyPressAnim()

        val p = player
        if (p != null) {
            if (shortsShown && !playerShown) bindShorts() else playerView.player = p
        }
        playerView.resizeMode = resizeModes[resizeIdx]
        btnAspect.text = resizeNames[resizeIdx]
        btnSpeed.text = speedText(speeds[speedIdx])
        btnPlay.setImageResource(if (p?.isPlaying == true) R.drawable.ic_pause else R.drawable.ic_play)
        tvTitle.text = queue.getOrNull(queueIndex)?.title ?: ""
        queueList.layoutManager = LinearLayoutManager(this)
        queueList.adapter = queueAdapter
        if (queue.isNotEmpty()) queueList.scrollToPosition(queueIndex)
        if (shortsShown) {
            shortsEmpty.visibility = if (shortsAdapter.items.isEmpty()) View.VISIBLE else View.GONE
            shortsPager.setCurrentItem(shortsIndex, false)
        }
        if (settingsShown) renderSettings()
        applyFx()
        updateMini()
        highlightNav()
        refreshList()
        skipAnim = true
        applyLayout()
        skipAnim = false
    }

    private fun speedText(s: Float): String =
        if (s == s.toInt().toFloat()) "${s.toInt()}.0x" else "${s}x"

    // =====================================================================
    // Library & navigation
    // =====================================================================

    private fun setupNav() {
        navItems.forEach { (sec, tv) ->
            tv.setOnClickListener {
                folderFilter = null
                showSection(sec)
            }
        }
        miniCard.setOnClickListener { reopenPlayer() }
    }

    private fun setupLibrary() {
        recycler.layoutAnimation =
            if (animOn) AnimationUtils.loadLayoutAnimation(this, R.anim.layout_enter) else null
        search.setText(query)
        search.doAfterTextChanged {
            query = it?.toString() ?: ""
            refreshList()
        }
        btnGrid.setOnClickListener {
            gridMode = true
            animateNext = true
            refreshList()
        }
        btnList.setOnClickListener {
            gridMode = false
            animateNext = true
            refreshList()
        }
        findViewById<View>(R.id.btnFile).setOnClickListener {
            pickLauncher.launch(arrayOf("video/*"))
        }
        findViewById<View>(R.id.btnUrl).setOnClickListener { askUrl() }
        findViewById<View>(R.id.btnRotate).setOnClickListener { toggleOrientation() }
    }

    private fun highlightNav() {
        val muted = ContextCompat.getColor(this, R.color.muted)
        navItems.forEach { (s, tv) ->
            val sel = s == section
            tv.setBackgroundResource(if (sel) R.drawable.bg_nav_selected else 0)
            tv.setTextColor(if (sel) Color.WHITE else muted)
            tv.compoundDrawableTintList = ColorStateList.valueOf(if (sel) Color.WHITE else muted)
        }
    }

    private fun showSection(sec: Section) {
        if (childLocked) return
        if (sec == Section.SHORTS && shortsShown && !playerShown) return
        section = sec
        closePlayerPane()
        settingsShown = sec == Section.SETTINGS
        if (sec == Section.SHORTS) {
            shortsShown = true
            highlightNav()
            applyLayout()
            openShorts()
            return
        }
        leaveShorts()
        if (settingsShown) renderSettings()
        highlightNav()
        animateNext = true
        refreshList()
        applyLayout()
    }

    private fun spanCount(itemDp: Int): Int {
        val used = if (isPortrait()) 20 else 168 + 24
        val avail = resources.configuration.screenWidthDp - used
        return (avail / itemDp).coerceAtLeast(2)
    }

    private fun refreshList() {
        val q = query.trim().lowercase()
        val byUri = allVideos.associateBy { it.uri.toString() }
        var title = "Videos"
        var showFolders = false
        val limit = shortMs()
        val base: List<VideoItem> = when (section) {
            Section.LIBRARY -> allVideos.filter { it.durationMs > limit }
            Section.SHORTS -> {
                title = "Shorts"
                allVideos.filter { it.durationMs <= limit }
            }
            Section.PLAYLIST -> {
                title = "Playlist"
                store.playlist().mapNotNull { byUri[it] }
            }
            Section.FAVORITES -> {
                title = "Favorites"
                store.favorites().mapNotNull { byUri[it] }
            }
            Section.HISTORY -> {
                title = "History"
                store.history().mapNotNull { byUri[it] }
            }
            Section.SETTINGS -> {
                title = "Settings"
                emptyList<VideoItem>()
            }
            Section.FOLDERS -> {
                val f = folderFilter
                if (f == null) {
                    title = "Folders"
                    showFolders = true
                    emptyList<VideoItem>()
                } else {
                    title = "‹  $f"
                    allVideos.filter { it.folder == f }
                }
            }
        }
        val list = base.filter { q.isEmpty() || it.title.lowercase().contains(q) }
        shown = list
        sectionTitle.text = title

        if (showFolders) {
            val groups = allVideos.groupBy { it.folder }
                .map { Pair(it.key, it.value.size) }
                .filter { q.isEmpty() || it.first.lowercase().contains(q) }
                .sortedBy { it.first.lowercase() }
            folderAdapter.items = groups
            recycler.layoutManager = LinearLayoutManager(this)
            recycler.adapter = folderAdapter
            folderAdapter.notifyDataSetChanged()
            setEmpty(groups.isEmpty())
        } else {
            val mode = if (gridMode) 1 else 0
            recycler.layoutManager =
                if (gridMode) GridLayoutManager(this, spanCount(150)) else LinearLayoutManager(this)
            recycler.adapter = videoAdapter
            videoAdapter.submit(list, mode)
            setEmpty(list.isEmpty())
        }

        if (animateNext) {
            animateNext = false
            if (animOn) recycler.scheduleLayoutAnimation()
        }

        val accent = ContextCompat.getColor(this, R.color.accent)
        val muted = ContextCompat.getColor(this, R.color.muted)
        btnGrid.setColorFilter(if (gridMode) accent else muted)
        btnList.setColorFilter(if (gridMode) muted else accent)
    }

    private fun setEmpty(isEmpty: Boolean) {
        if (isEmpty) {
            val res = when {
                denied -> R.string.no_permission
                section == Section.LIBRARY || section == Section.FOLDERS -> R.string.empty
                else -> R.string.nothing
            }
            emptyView.setText(res)
        }
        emptyView.visibility = if (isEmpty) View.VISIBLE else View.GONE
    }

    private fun showItemMenu(item: VideoItem, anchor: View) {
        val u = item.uri.toString()
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, if (store.isFav(u)) "Remove from favorites" else "Add to favorites")
        pm.menu.add(0, 2, 1, if (store.inPlaylist(u)) "Remove from playlist" else "Add to playlist")
        pm.menu.add(0, 3, 2, "Video info")
        pm.setOnMenuItemClickListener { m ->
            when (m.itemId) {
                1 -> store.toggleFav(u)
                2 -> store.togglePlaylist(u)
                3 -> showVideoInfo(item)
            }
            refreshList()
            true
        }
        pm.show()
    }

    private fun requestAndLoad() {
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED) {
            loadVideos()
        } else {
            permissionLauncher.launch(perm)
        }
    }

    private fun loadVideos() {
        Thread {
            val out = mutableListOf<VideoItem>()
            val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val proj = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
                MediaStore.Video.Media.DATA,
                MediaStore.Video.Media.DATE_MODIFIED
            )
            // duration > 0 filters out code files (.ts etc.) that Android mistakes for MPEG-TS video
            contentResolver.query(
                base, proj, "${MediaStore.Video.Media.DURATION} > 0", null,
                "${MediaStore.Video.Media.DATE_ADDED} DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    out.add(
                        VideoItem(
                            ContentUris.withAppendedId(base, c.getLong(0)),
                            c.getString(1) ?: "Video",
                            c.getLong(2),
                            c.getLong(3),
                            c.getString(4) ?: "Other",
                            c.getString(5) ?: "",
                            c.getLong(6) * 1000L
                        )
                    )
                }
            }
            runOnUiThread {
                denied = false
                allVideos.clear()
                allVideos.addAll(out)
                animateNext = true
                refreshList()
                if (shortsShown && !playerShown) openShorts()
            }
        }.start()
    }

    private fun askUrl() {
        val et = EditText(this).apply {
            hint = "https://example.com/video.mp4"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        val box = FrameLayout(this).apply {
            setPadding(48, 16, 48, 0)
            addView(et)
        }
        AlertDialog.Builder(this)
            .setTitle("Stream URL")
            .setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val u = et.text.toString().trim()
                if (u.isNotEmpty()) playUri(Uri.parse(u))
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun nameOf(u: Uri): String {
        var n: String? = null
        if (u.scheme == "content") {
            runCatching {
                contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { if (it.moveToFirst()) n = it.getString(0) }
            }
        }
        return n ?: u.lastPathSegment ?: "Video"
    }

    // =====================================================================
    // Shorts feed (vertical, TikTok style)
    // =====================================================================

    private fun setupShorts() {
        shortsPager.orientation = ViewPager2.ORIENTATION_VERTICAL
        shortsPager.adapter = shortsAdapter
        shortsPager.offscreenPageLimit = 1
        if (animOn) {
            shortsPager.setPageTransformer { page, position ->
                val d = abs(position).coerceAtMost(1f)
                page.alpha = 1f - 0.35f * d
                page.scaleX = 1f - 0.06f * d
                page.scaleY = 1f - 0.06f * d
            }
        } else {
            shortsPager.setPageTransformer(null)
        }
        shortsPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                onShortSelected(position)
            }
        })
        btnRotateShorts.setOnClickListener { toggleOrientation() }
        btnChildLock.setOnClickListener { onChildLockClick() }
    }

    // =====================================================================
    // Child lock (Shorts): only scrolling stays active until the PIN is entered
    // =====================================================================

    private fun updateChildLockUi() {
        btnChildLock.setImageResource(if (childLocked) R.drawable.ic_lock else R.drawable.ic_lock_open)
        btnChildLock.setColorFilter(
            if (childLocked) ContextCompat.getColor(this, R.color.accent) else Color.WHITE
        )
        btnRotateShorts.visibility = if (childLocked) View.GONE else View.VISIBLE
    }

    private fun onChildLockClick() {
        if (childLocked) {
            askPin("Enter PIN to unlock", "PIN") { pin ->
                if (pin == store.pin()) {
                    setChildLock(false)
                } else {
                    Toast.makeText(this, "Wrong PIN", Toast.LENGTH_SHORT).show()
                }
            }
        } else if (store.pin().isEmpty()) {
            askPin("Set a PIN (4-6 digits)", "PIN") { pin ->
                if (pin.length >= 4) {
                    store.setPin(pin)
                    setChildLock(true)
                } else {
                    Toast.makeText(this, "PIN must be 4-6 digits", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            setChildLock(true)
        }
    }

    private fun setChildLock(on: Boolean) {
        childLocked = on
        store.putBool("childlock", on)
        shortsAdapter.applyLock(on)
        if (on) {
            runCatching { startLockTask() }
            Toast.makeText(this, "Child lock on", Toast.LENGTH_SHORT).show()
        } else {
            runCatching { stopLockTask() }
            Toast.makeText(this, "Child lock off", Toast.LENGTH_SHORT).show()
        }
        applyLayout()
    }

    private fun askPin(title: String, hint: String, onOk: (String) -> Unit) {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        et.hint = hint
        et.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(6))
        val box = FrameLayout(this)
        box.setPadding(48, 16, 48, 0)
        box.addView(et)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ -> onOk(et.text.toString()) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun changePin() {
        val cur = store.pin()
        fun askNew() {
            askPin("New PIN (4-6 digits)", "New PIN") { n ->
                if (n.length >= 4) {
                    store.setPin(n)
                    Toast.makeText(this, "PIN saved", Toast.LENGTH_SHORT).show()
                    renderSettings()
                } else {
                    Toast.makeText(this, "PIN must be 4-6 digits", Toast.LENGTH_SHORT).show()
                }
            }
        }
        if (cur.isEmpty()) {
            askNew()
        } else {
            askPin("Current PIN", "PIN") { entered ->
                if (entered == cur) {
                    askNew()
                } else {
                    Toast.makeText(this, "Wrong PIN", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun openShorts() {
        val list = allVideos.filter { it.durationMs <= shortMs() }
        shortsAdapter.items = list
        shortsAdapter.notifyDataSetChanged()
        shortsEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        if (list.isEmpty()) {
            player?.pause()
            return
        }
        savePosition()
        queue = list
        queueIsShorts = true
        shortsIndex = shortsIndex.coerceIn(0, list.size - 1)
        queueIndex = shortsIndex
        val p = player
        if (p == null) {
            initPlayer()
        } else {
            loadQueueInto(p)
            bindShorts()
        }
        shortsPager.setCurrentItem(shortsIndex, false)
        applyLayout()
    }

    private fun bindShorts() {
        playerView.player = null
        shortsAdapter.player = player
        shortsAdapter.setActive(queueIndex)
    }

    private fun leaveShorts() {
        if (!shortsShown) return
        shortsShown = false
        player?.pause()
        shortsAdapter.detachAll()
    }

    private fun onShortSelected(pos: Int) {
        if (!shortsShown || !queueIsShorts) return
        shortsIndex = pos
        queueIndex = pos
        val p = player
        if (p != null && pos != p.currentMediaItemIndex) p.seekTo(pos, 0L)
        p?.playWhenReady = true
        shortsAdapter.setActive(pos)
        shortsAdapter.items.getOrNull(pos)?.let { store.addHistory(it.uri.toString()) }
    }

    // =====================================================================
    // Playback (one ExoPlayer instance is reused for every video)
    // =====================================================================

    private fun playUri(uri: Uri) {
        if (uri.scheme == "content") {
            runCatching {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        playQueue(listOf(VideoItem(uri, nameOf(uri))), 0)
    }

    private fun playQueue(list: List<VideoItem>, index: Int) {
        if (list.isEmpty()) return
        savePosition()
        leaveShorts()
        settingsShown = false
        if (section == Section.SHORTS || section == Section.SETTINGS) {
            section = Section.LIBRARY
            highlightNav()
            refreshList()
        }
        queue = list
        queueIsShorts = false
        queueIndex = index.coerceIn(0, list.size - 1)
        queueAdapter.items = queue
        queueAdapter.current = queueIndex
        queueAdapter.notifyDataSetChanged()
        playerShown = true
        val p = player
        if (p == null) {
            initPlayer()
        } else {
            loadQueueInto(p)
            bindPlayerView()
        }
        applyLayout()
    }

    private fun reopenPlayer() {
        if (queue.isEmpty() || queueIsShorts) return
        playerShown = true
        initPlayer()
        bindPlayerView()
        player?.play()
        applyLayout()
    }

    private fun closePlayerPane() {
        if (playerShown) player?.pause()
        val wasFull = fullscreen
        playerShown = false
        fullscreen = false
        locked = false
        if (wasFull) applyOrientation()
        applyLayout()
    }

    private fun initPlayer() {
        if (queue.isEmpty() || player != null) return
        val factory = DefaultRenderersFactory(this).setEnableDecoderFallback(true)
        val p = ExoPlayer.Builder(this, factory)
            .setHandleAudioBecomingNoisy(true)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            .build()
        p.addListener(playerListener)
        p.setPlaybackSpeed(speeds[speedIdx])
        player = p
        attachEnhancer(p.audioSessionId)
        if (shortsShown && !playerShown) bindShorts() else bindPlayerView()
        loadQueueInto(p)
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    private fun bindPlayerView() {
        shortsAdapter.detachAll()
        playerView.player = null
        playerView.player = player
        applyFx()
    }

    private fun loadQueueInto(p: ExoPlayer) {
        val shortsMode = shortsShown && !playerShown
        val media = queue.map {
            MediaItem.Builder()
                .setUri(it.uri)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(it.title).build())
                .build()
        }
        val start = if (resumeOn && !shortsMode) store.getPos(queue[queueIndex].uri.toString()) else 0L
        p.repeatMode = if (shortsMode) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        p.setMediaItems(media, queueIndex, start)
        p.prepare()
        p.playWhenReady = true
        if (!shortsMode) onItemChanged(queueIndex)
    }

    private fun savePosition() {
        if (queueIsShorts) return
        val p = player ?: return
        val uri = p.currentMediaItem?.localConfiguration?.uri ?: return
        val pos = if (p.playbackState == Player.STATE_ENDED) 0L else p.currentPosition
        store.setPos(uri.toString(), pos)
    }

    private fun releasePlayer() {
        handler.removeCallbacks(ticker)
        val p = player ?: return
        savePosition()
        queueIndex = p.currentMediaItemIndex.coerceAtLeast(0)
        shortsAdapter.detachAll()
        shortsAdapter.player = null
        playerView.player = null
        p.removeListener(playerListener)
        runCatching { enhancer?.release() }
        enhancer = null
        p.release()
        player = null
    }

    private fun onItemChanged(i: Int) {
        queueIndex = i
        val item = queue.getOrNull(i) ?: return
        tvTitle.text = item.title
        store.addHistory(item.uri.toString())
        queueAdapter.current = i
        queueAdapter.notifyDataSetChanged()
        queueList.scrollToPosition(i)
        updateMini()
        applyLayout()
    }

    private fun updateMini() {
        val item = queue.getOrNull(queueIndex) ?: return
        miniName.text = item.title
        val vs = player?.videoSize
        var res = ""
        if (vs != null && vs.width > 0 && vs.height > 0) {
            val tag = resTag(minOf(vs.width, vs.height))
            res = "${vs.width} x ${vs.height}$tag"
        }
        val size = if (item.size > 0) Formatter.formatShortFileSize(this, item.size) else ""
        miniMeta.text = listOf(res, size).filter { it.isNotEmpty() }.joinToString("  ·  ")
        Glide.with(miniThumb).load(item.uri).centerCrop().dontAnimate().override(120, 80).into(miniThumb)
    }

    // =====================================================================
    // Volume: 0-100% = system volume, 100-200% = extra boost (LoudnessEnhancer)
    // =====================================================================

    private fun currentVolPercent(): Int {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val sys = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        return if (boostPct > 100) boostPct else (sys * 100f / max).roundToInt()
    }

    private fun setVolumePercent(pct: Int) {
        val p = pct.coerceIn(0, 200)
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (p <= 100) {
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, (p / 100f * max).roundToInt(), 0)
            setBoost(100)
        } else {
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, max, 0)
            setBoost(p)
        }
        volSeek.progress = p
    }

    private fun setBoost(pct: Int) {
        boostPct = pct
        val gainMb = if (pct <= 100) 0 else (2000.0 * log10(pct / 100.0)).roundToInt()
        val e = enhancer
        if (e != null) {
            runCatching {
                e.setTargetGain(gainMb)
                e.setEnabled(pct > 100)
            }
        }
    }

    private fun attachEnhancer(session: Int) {
        runCatching { enhancer?.release() }
        enhancer = null
        if (session == C.AUDIO_SESSION_ID_UNSET || session == 0) return
        enhancer = runCatching { LoudnessEnhancer(session) }.getOrNull()
        setBoost(boostPct)
    }

    private fun syncVolume() {
        if (!::volSeek.isInitialized) return
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val sys = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        if (boostPct > 100 && sys < max) setBoost(100)
        volSeek.progress = currentVolPercent()
    }

    // =====================================================================
    // Display enhancement (subtle AMOLED-style colour grade)
    // =====================================================================

    private fun applyFx() {
        applyFxTo(playerView)
        val on = ContextCompat.getColor(this, R.color.accent)
        val off = ContextCompat.getColor(this, R.color.muted)
        btnFx.setColorFilter(if (fxMode == 0) off else on)
    }

    private fun applyFxTo(pv: PlayerView) {
        val surface = pv.videoSurfaceView
        if (surface !is TextureView) return
        if (fxMode == 0) {
            surface.setLayerType(View.LAYER_TYPE_NONE, null)
            return
        }
        val soft = fxMode == 1
        val sat = if (soft) 1.10f else 1.22f
        val s = if (soft) 1.06f else 1.12f
        val t = if (soft) -9f else -17f
        val cm = ColorMatrix()
        cm.setSaturation(sat)
        cm.postConcat(
            ColorMatrix(
                floatArrayOf(
                    s, 0f, 0f, 0f, t,
                    0f, s, 0f, 0f, t,
                    0f, 0f, s, 0f, t,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
        val paint = Paint()
        paint.colorFilter = ColorMatrixColorFilter(cm)
        surface.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
    }

    // =====================================================================
    // Player UI
    // =====================================================================

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** Fade (and slightly slide) a view in or out; instant when animations are off. */
    private fun animVisible(v: View, visible: Boolean, dxDp: Int = 0, dyDp: Int = 0) {
        v.animate().cancel()
        if (!animOn || skipAnim) {
            v.alpha = 1f
            v.translationX = 0f
            v.translationY = 0f
            v.visibility = if (visible) View.VISIBLE else View.GONE
            return
        }
        val dx = dp(dxDp).toFloat()
        val dy = dp(dyDp).toFloat()
        if (visible) {
            if (v.visibility != View.VISIBLE) {
                v.alpha = 0f
                v.translationX = dx
                v.translationY = dy
                v.visibility = View.VISIBLE
            }
            v.animate().alpha(1f).translationX(0f).translationY(0f).setDuration(240).start()
        } else if (v.visibility == View.VISIBLE) {
            v.animate().alpha(0f).translationX(dx / 2).translationY(dy / 2).setDuration(160)
                .withEndAction {
                    v.visibility = View.GONE
                    v.alpha = 1f
                    v.translationX = 0f
                    v.translationY = 0f
                }.start()
        }
    }

    /** Small "press" scale on buttons (does not consume the touch, clicks still work). */
    @SuppressLint("ClickableViewAccessibility")
    private fun applyPressAnim() {
        val ids = intArrayOf(
            R.id.btnBack, R.id.btnQueue, R.id.btnRotatePlayer, R.id.btnPlay, R.id.btnPrev,
            R.id.btnNext, R.id.btnRew, R.id.btnFwd, R.id.btnPip, R.id.btnFull, R.id.btnCc,
            R.id.btnAudio, R.id.btnSpeed, R.id.btnAspect, R.id.btnFx, R.id.btnGrid, R.id.btnList,
            R.id.btnFile, R.id.btnUrl, R.id.btnRotate, R.id.btnRotateShorts, R.id.btnChildLock,
            R.id.btnLock, R.id.btnUnlock
        )
        val views = ArrayList<View>()
        for (id in ids) views.add(findViewById(id))
        views.addAll(navItems.values)
        views.add(miniCard)
        for (target in views) {
            target.setOnTouchListener { view, ev ->
                if (animOn) {
                    when (ev.actionMasked) {
                        MotionEvent.ACTION_DOWN ->
                            view.animate().scaleX(0.9f).scaleY(0.9f).setDuration(90).start()
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                            view.animate().scaleX(1f).scaleY(1f).setDuration(150).start()
                    }
                }
                false
            }
        }
    }

    private fun applyLayout() {
        val full = playerShown && (fullscreen || inPip)
        val portrait = isPortrait()
        val ctlH = resources.getDimensionPixelSize(R.dimen.controls_h)
        val feed = shortsShown && !playerShown
        val settings = settingsShown && !playerShown

        animVisible(libraryPane, !(playerShown || feed || settings), dyDp = 10)
        animVisible(playerPane, playerShown, dyDp = 10)
        animVisible(shortsPane, feed, dyDp = 10)
        animVisible(settingsPane, settings, dyDp = 10)
        sidebar.visibility = if (full || childLocked) View.GONE else View.VISIBLE
        topBar.visibility = if (full) View.GONE else View.VISIBLE
        val miniVisible = when {
            queue.isEmpty() || full || queueIsShorts || feed -> false
            portrait && playerShown -> false
            else -> true
        }
        animVisible(miniCard, miniVisible, dyDp = 8)

        val showQueue = queueShown && !full
        animVisible(queuePanel, showQueue, dxDp = if (portrait) 0 else 24, dyDp = if (portrait) 24 else 0)
        volSeek.visibility =
            if (!portrait && showQueue && resources.configuration.screenWidthDp < 1000) View.GONE
            else View.VISIBLE

        val ctlVisible = when {
            !playerShown || inPip || locked -> false
            fullscreen -> controlsShown
            else -> true
        }
        animVisible(controls, ctlVisible, dyDp = 18)
        controls.setBackgroundResource(
            if (full) R.drawable.bg_controls_overlay else R.drawable.bg_controls_solid
        )
        animVisible(btnLock, fullscreen && controlsShown && !locked && !inPip)
        animVisible(btnUnlock, locked)

        val lp = playerView.layoutParams as FrameLayout.LayoutParams
        lp.bottomMargin = if (full || locked) 0 else ctlH
        playerView.layoutParams = lp

        // Portrait: the video box is always 16:9 (vertical videos stay letterboxed inside it).
        val vlp = videoArea.layoutParams as LinearLayout.LayoutParams
        if (portrait && !full) {
            vlp.height = resources.displayMetrics.widthPixels * 9 / 16 + ctlH
            vlp.weight = 0f
        } else {
            vlp.height = 0
            vlp.weight = 1f
        }
        videoArea.layoutParams = vlp

        updateChildLockUi()
        updateSystemBars()
    }

    private fun setFullscreen(on: Boolean) {
        fullscreen = on
        controlsShown = true
        applyOrientation()
        applyLayout()
        scheduleHideControls()
    }

    private fun scheduleHideControls() {
        handler.removeCallbacks(hideControls)
        if (fullscreen && controlsShown) handler.postDelayed(hideControls, 3500)
    }

    private fun showInfo(text: String, sticky: Boolean = false) {
        info.text = text
        info.animate().cancel()
        if (animOn) {
            if (info.visibility != View.VISIBLE) {
                info.alpha = 0f
                info.scaleX = 0.9f
                info.scaleY = 0.9f
                info.visibility = View.VISIBLE
            }
            info.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(140).start()
        } else {
            info.alpha = 1f
            info.scaleX = 1f
            info.scaleY = 1f
            info.visibility = View.VISIBLE
        }
        handler.removeCallbacks(hideInfo)
        if (!sticky) handler.postDelayed(hideInfo, 800)
    }

    private fun seekBy(deltaMs: Long) {
        val p = player ?: return
        val t = p.currentPosition + deltaMs
        val dur = p.duration
        p.seekTo(if (dur > 0) t.coerceIn(0L, dur) else t.coerceAtLeast(0L))
        showInfo(if (deltaMs < 0) "⏪ ${abs(deltaMs) / 1000}s" else "+${deltaMs / 1000}s ⏩")
        scheduleHideControls()
    }

    private fun setupPlayerUi() {
        findViewById<View>(R.id.btnBack).setOnClickListener { handleBack() }
        findViewById<View>(R.id.btnQueue).setOnClickListener {
            queueShown = !queueShown
            applyLayout()
        }
        findViewById<View>(R.id.btnRotatePlayer).setOnClickListener { toggleOrientation() }
        btnFx.setOnClickListener {
            fxMode = (fxMode + 1) % 3
            store.setFx(fxMode)
            applyFx()
            showInfo("Display: " + fxNames[fxMode])
        }
        btnAspect.setOnClickListener {
            resizeIdx = (resizeIdx + 1) % resizeModes.size
            playerView.resizeMode = resizeModes[resizeIdx]
            btnAspect.text = resizeNames[resizeIdx]
            showInfo(resizeNames[resizeIdx])
        }

        btnPlay.setOnClickListener {
            val p = player
            if (p != null) {
                if (p.isPlaying) {
                    p.pause()
                } else {
                    if (p.playbackState == Player.STATE_ENDED) p.seekTo(0L)
                    p.play()
                }
            }
            scheduleHideControls()
        }
        findViewById<View>(R.id.btnPrev).setOnClickListener {
            val p = player
            if (p != null) {
                if (p.hasPreviousMediaItem()) p.seekToPreviousMediaItem() else p.seekTo(0L)
            }
        }
        findViewById<View>(R.id.btnNext).setOnClickListener {
            val p = player
            if (p != null && p.hasNextMediaItem()) p.seekToNextMediaItem()
        }
        findViewById<View>(R.id.btnRew).setOnClickListener { seekBy(-10_000L) }
        findViewById<View>(R.id.btnFwd).setOnClickListener { seekBy(30_000L) }
        findViewById<View>(R.id.btnPip).setOnClickListener { enterPip() }
        findViewById<View>(R.id.btnFull).setOnClickListener { setFullscreen(!fullscreen) }
        findViewById<View>(R.id.btnCc).setOnClickListener { pickTrack(C.TRACK_TYPE_TEXT, "Subtitles") }
        findViewById<View>(R.id.btnAudio).setOnClickListener { pickTrack(C.TRACK_TYPE_AUDIO, "Audio") }
        btnSpeed.setOnClickListener {
            speedIdx = (speedIdx + 1) % speeds.size
            player?.setPlaybackSpeed(speeds[speedIdx])
            btnSpeed.text = speedText(speeds[speedIdx])
            scheduleHideControls()
        }
        btnLock.setOnClickListener { setLocked(true) }
        btnUnlock.setOnClickListener { setLocked(false) }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val d = player?.duration ?: 0L
                    if (d > 0) tvPos.text = fmt(d * progress / 1000)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                seeking = true
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                seeking = false
                val p = player
                val prog = seekBar?.progress ?: 0
                if (p != null && p.duration > 0) p.seekTo(p.duration * prog / 1000)
                scheduleHideControls()
            }
        })

        volSeek.max = 200
        volSeek.progress = currentVolPercent()
        volSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) setVolumePercent(progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun setLocked(value: Boolean) {
        locked = value
        controlsShown = true
        applyLayout()
        if (!value) scheduleHideControls()
    }

    private fun pickTrack(type: Int, title: String) {
        val p = player ?: return
        val groups = p.currentTracks.groups.filter { it.type == type && it.isSupported }
        if (groups.isEmpty()) {
            Toast.makeText(this, "No $title tracks", Toast.LENGTH_SHORT).show()
            return
        }
        val names = ArrayList<String>()
        if (type == C.TRACK_TYPE_TEXT) names.add("Off")
        groups.forEachIndexed { i, g ->
            val f = g.getTrackFormat(0)
            names.add(f.label ?: f.language ?: "Track ${i + 1}")
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(names.toTypedArray()) { _, which ->
                val b = p.trackSelectionParameters.buildUpon()
                if (type == C.TRACK_TYPE_TEXT) {
                    if (which == 0) {
                        b.setTrackTypeDisabled(type, true)
                    } else {
                        b.setTrackTypeDisabled(type, false)
                        b.setOverrideForType(TrackSelectionOverride(groups[which - 1].mediaTrackGroup, 0))
                    }
                } else {
                    b.setOverrideForType(TrackSelectionOverride(groups[which].mediaTrackGroup, 0))
                }
                p.trackSelectionParameters = b.build()
            }
            .show()
    }

    private fun enterPip() {
        val p = player ?: return
        if (Build.VERSION.SDK_INT < 26 || !playerShown) return
        val vs = p.videoSize
        val r = if (vs.width > 0 && vs.height > 0) vs.width.toFloat() / vs.height else 16f / 9f
        val ratio = Rational((r.coerceIn(0.5f, 2.0f) * 1000).toInt(), 1000)
        runCatching {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(ratio).build())
        }
    }

    // =====================================================================
    // Settings screen
    // =====================================================================

    private fun choose(title: String, options: Array<String>, current: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(options, current) { dialog, which ->
                onPick(which)
                dialog.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun addRow(title: String, value: String, onClick: (() -> Unit)? = null) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(16), dp(14), dp(16), dp(14))

        val t = TextView(this)
        t.text = title
        t.setTextColor(Color.WHITE)
        t.textSize = 15f
        t.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

        val v = TextView(this)
        v.text = value
        v.setTextColor(ContextCompat.getColor(this, R.color.accent))
        v.textSize = 14f

        row.addView(t)
        row.addView(v)
        if (onClick != null) {
            val tv = TypedValue()
            theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
            row.setBackgroundResource(tv.resourceId)
            row.setOnClickListener { onClick() }
        }
        settingsList.addView(row)

        val line = View(this)
        line.setBackgroundColor(ContextCompat.getColor(this, R.color.stroke))
        line.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
        settingsList.addView(line)
    }

    private fun onOff(b: Boolean): String = if (b) "On" else "Off"

    private fun renderSettings() {
        settingsList.removeAllViews()

        addRow("Display enhancement", fxNames[fxMode]) {
            choose("Display enhancement", fxNames, fxMode) { i ->
                fxMode = i
                store.setFx(i)
                applyFx()
                shortsAdapter.refreshFx()
                renderSettings()
            }
        }
        addRow("Screen orientation", orientNames[orientationMode]) {
            choose("Screen orientation", orientNames, orientationMode) { i ->
                orientationMode = i
                store.putInt("orient", i)
                applyOrientation()
                renderSettings()
            }
        }
        addRow("Default playback speed", speedText(speeds[speedIdx])) {
            val labels = Array(speeds.size) { speedText(speeds[it]) }
            choose("Default playback speed", labels, speedIdx) { i ->
                speedIdx = i
                store.putInt("speed", i)
                player?.setPlaybackSpeed(speeds[i])
                btnSpeed.text = speedText(speeds[i])
                renderSettings()
            }
        }
        addRow("Default aspect ratio", resizeNames[resizeIdx]) {
            choose("Default aspect ratio", resizeNames, resizeIdx) { i ->
                resizeIdx = i
                store.putInt("aspect", i)
                playerView.resizeMode = resizeModes[i]
                btnAspect.text = resizeNames[i]
                renderSettings()
            }
        }
        addRow("Double-tap seek", "$dtapSec s") {
            val opts = intArrayOf(5, 10, 15, 30)
            val labels = Array(opts.size) { "${opts[it]} s" }
            choose("Double-tap seek", labels, opts.indexOf(dtapSec)) { i ->
                dtapSec = opts[i]
                store.putInt("dtap", dtapSec)
                renderSettings()
            }
        }
        addRow("Resume from last position", onOff(resumeOn)) {
            resumeOn = !resumeOn
            store.putBool("resume", resumeOn)
            renderSettings()
        }
        addRow("Swipe gestures", onOff(gesturesOn)) {
            gesturesOn = !gesturesOn
            store.putBool("gestures", gesturesOn)
            renderSettings()
        }
        addRow("Shorts length limit", "${shortMs() / 1000} s") {
            val opts = intArrayOf(30, 60, 90, 180)
            val labels = Array(opts.size) { "${opts[it]} s" }
            choose("Shorts length limit", labels, opts.indexOf((shortMs() / 1000).toInt())) { i ->
                store.putInt("short", opts[i])
                shortsIndex = 0
                renderSettings()
                refreshList()
            }
        }
        addRow("Clear watch history", "") {
            store.clearHistory()
            Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show()
        }
        addRow("Animations", onOff(animOn)) {
            animOn = !animOn
            store.putBool("anim", animOn)
            shortsAdapter.animations = animOn
            recycler.layoutAnimation =
                if (animOn) AnimationUtils.loadLayoutAnimation(this, R.anim.layout_enter) else null
            if (animOn) {
                shortsPager.setPageTransformer { page, position ->
                    val d = abs(position).coerceAtMost(1f)
                    page.alpha = 1f - 0.35f * d
                    page.scaleX = 1f - 0.06f * d
                    page.scaleY = 1f - 0.06f * d
                }
            } else {
                shortsPager.setPageTransformer(null)
            }
            renderSettings()
        }
        addRow("Video info", "Current video") {
            showVideoInfo(queue.getOrNull(queueIndex))
        }
        addRow("Child lock PIN", if (store.pin().isEmpty()) "Not set" else "Change") {
            changePin()
        }
        addRow("Extra volume", "Up to 200%")
        addRow("About", "VoxaZ Studio 1.0.0")
    }

    // =====================================================================
    // Video info
    // =====================================================================

    private fun resTag(shortSide: Int): String = when {
        shortSide >= 2160 -> "  ·  4K"
        shortSide >= 1440 -> "  ·  2K"
        shortSide >= 1080 -> "  ·  FHD"
        shortSide >= 720 -> "  ·  HD"
        else -> ""
    }

    private fun codecName(mime: String): String = when (mime) {
        "video/avc" -> "H.264 / AVC"
        "video/hevc" -> "H.265 / HEVC"
        "video/x-vnd.on2.vp9" -> "VP9"
        "video/x-vnd.on2.vp8" -> "VP8"
        "video/av01" -> "AV1"
        "video/mp4v-es" -> "MPEG-4 Visual"
        "video/3gpp" -> "H.263"
        "video/dolby-vision" -> "Dolby Vision"
        "audio/mp4a-latm" -> "AAC"
        "audio/mpeg" -> "MP3"
        "audio/ac3" -> "AC-3 (Dolby Digital)"
        "audio/eac3" -> "E-AC-3 (Dolby Digital Plus)"
        "audio/opus" -> "Opus"
        "audio/vorbis" -> "Vorbis"
        "audio/flac" -> "FLAC"
        "audio/raw" -> "PCM"
        "audio/amr-wb", "audio/3gpp" -> "AMR"
        else -> mime
    }

    private fun bitrateText(bps: Long): String =
        if (bps >= 1_000_000) String.format(Locale.US, "%.2f Mbps", bps / 1_000_000.0)
        else "${bps / 1000} kbps"

    private fun channelText(n: Int): String = when (n) {
        1 -> "Mono"
        2 -> "Stereo"
        6 -> "5.1"
        8 -> "7.1"
        else -> "$n ch"
    }

    private fun ratioText(w: Int, h: Int): String {
        if (w <= 0 || h <= 0) return ""
        var a = w
        var b = h
        while (b != 0) {
            val t = a % b
            a = b
            b = t
        }
        val rw = w / a
        val rh = h / a
        return if (rw <= 32 && rh <= 32) "$rw:$rh" else String.format(Locale.US, "%.2f:1", w.toFloat() / h)
    }

    private fun numOf(f: MediaFormat, key: String): Double? {
        if (!f.containsKey(key)) return null
        return runCatching { f.getInteger(key).toDouble() }.getOrNull()
            ?: runCatching { f.getFloat(key).toDouble() }.getOrNull()
            ?: runCatching { f.getLong(key).toDouble() }.getOrNull()
    }

    private fun showVideoInfo(item: VideoItem?) {
        if (item == null) {
            Toast.makeText(this, "Play a video first", Toast.LENGTH_SHORT).show()
            return
        }
        infoText = ""
        val dlg = AlertDialog.Builder(this)
            .setTitle("Video info")
            .setMessage("Loading...")
            .setPositiveButton(android.R.string.ok, null)
            .setNeutralButton("Copy") { _, _ ->
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Video info", infoText))
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
            }
            .create()
        dlg.show()
        Thread {
            val text = runCatching { buildInfo(item) }
                .getOrElse { "Could not read the details of this video." }
            runOnUiThread {
                infoText = text
                dlg.setMessage(text)
            }
        }.start()
    }

    private fun buildInfo(item: VideoItem): String {
        val sb = StringBuilder()
        fun line(k: String, v: String?) {
            if (!v.isNullOrBlank()) sb.append(k).append(": ").append(v).append('\n')
        }
        fun head(t: String) {
            if (sb.isNotEmpty()) sb.append('\n')
            sb.append("— ").append(t).append(" —\n")
        }

        // container / overall data
        var container: String? = null
        var overall: Long = 0
        var capFps: Double? = null
        var rotation = 0
        var durMs = item.durationMs
        var location: String? = null
        val mmr = MediaMetadataRetriever()
        runCatching {
            mmr.setDataSource(this, item.uri)
            container = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE)
            overall = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull() ?: 0L
            capFps = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)?.toDoubleOrNull()
            rotation = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            val d = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            if (d != null && d > 0) durMs = d
            location = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_LOCATION)
        }
        runCatching { mmr.release() }

        head("General")
        line("Name", item.title)
        if (item.folder.isNotEmpty()) line("Folder", item.folder)
        line("Path", item.path)
        if (item.size > 0) {
            line("Size", Formatter.formatFileSize(this, item.size) + "  (" + item.size + " bytes)")
        }
        if (durMs > 0) line("Duration", fmt(durMs) + "  (" + durMs + " ms)")
        line("Container", container)
        if (overall > 0) line("Overall bitrate", bitrateText(overall))
        if (item.dateMs > 0) line("Modified", DateFormat.getDateTimeInstance().format(Date(item.dateMs)))
        line("Location", location)

        // tracks
        val ex = MediaExtractor()
        var videoCount = 0
        var audioCount = 0
        var textCount = 0
        runCatching {
            ex.setDataSource(this, item.uri, null)
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/")) {
                    videoCount++
                    if (videoCount == 1) {
                        head("Video")
                        var w = numOf(f, MediaFormat.KEY_WIDTH)?.toInt() ?: 0
                        var h = numOf(f, MediaFormat.KEY_HEIGHT)?.toInt() ?: 0
                        val r = numOf(f, "rotation-degrees")?.toInt() ?: rotation
                        if (r == 90 || r == 270) {
                            val t = w
                            w = h
                            h = t
                        }
                        line("Codec", codecName(mime))
                        if (w > 0 && h > 0) {
                            line("Resolution", "$w x $h" + resTag(minOf(w, h)))
                            line("Aspect ratio", ratioText(w, h))
                        }
                        val fps = numOf(f, MediaFormat.KEY_FRAME_RATE) ?: capFps
                        if (fps != null && fps > 0) {
                            line(
                                "Frame rate",
                                if (abs(fps - fps.roundToInt()) < 0.01) "${fps.roundToInt()} fps"
                                else String.format(Locale.US, "%.2f fps", fps)
                            )
                        }
                        val br = numOf(f, MediaFormat.KEY_BIT_RATE)
                        if (br != null && br > 0) line("Video bitrate", bitrateText(br.toLong()))
                        if (r != 0) line("Rotation", "$r°")
                        val ct = numOf(f, MediaFormat.KEY_COLOR_TRANSFER)?.toInt()
                        if (ct != null) {
                            line("Dynamic range", if (ct == 6) "HDR10 (PQ)" else if (ct == 7) "HLG HDR" else "SDR")
                        }
                        val cs = numOf(f, MediaFormat.KEY_COLOR_STANDARD)?.toInt()
                        if (cs != null) {
                            line("Color space", if (cs == 6) "BT.2020" else if (cs == 1) "BT.709" else "BT.601")
                        }
                    }
                } else if (mime.startsWith("audio/")) {
                    audioCount++
                    if (audioCount == 1) head("Audio")
                    val parts = ArrayList<String>()
                    parts.add(codecName(mime))
                    val ch = numOf(f, MediaFormat.KEY_CHANNEL_COUNT)?.toInt()
                    if (ch != null && ch > 0) parts.add(channelText(ch))
                    val sr = numOf(f, MediaFormat.KEY_SAMPLE_RATE)?.toInt()
                    if (sr != null && sr > 0) parts.add(String.format(Locale.US, "%.1f kHz", sr / 1000.0))
                    val ab = numOf(f, MediaFormat.KEY_BIT_RATE)
                    if (ab != null && ab > 0) parts.add(bitrateText(ab.toLong()))
                    if (f.containsKey(MediaFormat.KEY_LANGUAGE)) {
                        val lang = f.getString(MediaFormat.KEY_LANGUAGE)
                        if (!lang.isNullOrBlank() && lang != "und") parts.add(lang)
                    }
                    line("Track $audioCount", parts.joinToString("  ·  "))
                } else {
                    textCount++
                }
            }
        }
        runCatching { ex.release() }

        head("Tracks")
        line("Video / Audio / Subtitles", "$videoCount / $audioCount / $textCount")
        head("Source")
        line("URI", item.uri.toString())
        return sb.toString().trimEnd()
    }

    // =====================================================================
    // Gestures on the video surface
    // =====================================================================

    private fun setupGestures() {
        var mode = 0 // 0 none, 1 seek, 2 brightness, 3 volume
        var seekStart = 0L
        var seekOff = 0L
        var bright = 0.5f
        var vol = 0f
        var boosted = false

        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                mode = 0
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked || !fullscreen) return true
                controlsShown = !controlsShown
                applyLayout()
                scheduleHideControls()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val p = player ?: return true
                if (locked) return true
                val w = playerView.width
                if (e.x < w / 3f) {
                    seekBy(-dtapSec * 1000L)
                } else if (e.x > w * 2 / 3f) {
                    seekBy(dtapSec * 1000L)
                } else {
                    p.playWhenReady = !p.playWhenReady
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (locked || !gesturesOn) return
                player?.setPlaybackSpeed(2f)
                boosted = true
                showInfo("2x ⏩", sticky = true)
            }

            override fun onScroll(
                e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float
            ): Boolean {
                if (locked || !gesturesOn || e1 == null || boosted) return false
                val p = player ?: return false
                if (mode == 0) {
                    mode = if (abs(distanceX) > abs(distanceY)) 1
                    else if (e1.x < playerView.width / 2f) 2
                    else 3
                    if (mode == 1) {
                        seekStart = p.currentPosition
                        seekOff = 0L
                    } else if (mode == 2) {
                        val b = window.attributes.screenBrightness
                        bright = if (b < 0f) 0.5f else b
                    } else {
                        vol = currentVolPercent().toFloat()
                    }
                }
                val h = playerView.height.coerceAtLeast(1).toFloat()
                if (mode == 1) {
                    seekOff -= (distanceX * 100).toLong()
                    val t = (seekStart + seekOff).coerceIn(0L, p.duration.coerceAtLeast(0L))
                    val sign = if (seekOff >= 0) "+" else "-"
                    showInfo("${fmt(t)}  (${sign}${abs(seekOff) / 1000}s)")
                } else if (mode == 2) {
                    bright = (bright + distanceY / h).coerceIn(0.02f, 1f)
                    val lp = window.attributes
                    lp.screenBrightness = bright
                    window.attributes = lp
                    showInfo("☀ ${(bright * 100).roundToInt()}%")
                } else {
                    vol = (vol + distanceY / h * 260f).coerceIn(0f, 200f)
                    setVolumePercent(vol.roundToInt())
                    showInfo("🔊 ${vol.roundToInt()}%")
                }
                return true
            }
        })

        playerView.setOnTouchListener { _, ev ->
            detector.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                val p = player
                if (p != null && mode == 1) {
                    p.seekTo((seekStart + seekOff).coerceIn(0L, p.duration.coerceAtLeast(0L)))
                }
                if (boosted) {
                    p?.setPlaybackSpeed(speeds[speedIdx])
                    boosted = false
                    handler.post(hideInfo)
                }
                mode = 0
            }
            true
        }
    }
}
