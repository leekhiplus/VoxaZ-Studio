package com.voxaz.studio

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class MainActivity : AppCompatActivity() {

    private val videos = mutableListOf<VideoItem>()
    private lateinit var videoAdapter: VideoAdapter
    private lateinit var empty: TextView

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) loadVideos() else showEmpty(R.string.no_permission)
        }

    private val pickLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) open(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        empty = findViewById(R.id.empty)

        videoAdapter = VideoAdapter(videos) { index ->
            Playlist.items = videos.toList()
            startActivity(Intent(this, PlayerActivity::class.java).putExtra("index", index))
        }
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = videoAdapter
        }
        findViewById<View>(R.id.btnFile).setOnClickListener {
            pickLauncher.launch(arrayOf("video/*"))
        }
        findViewById<View>(R.id.btnUrl).setOnClickListener { askUrl() }

        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED) {
            loadVideos()
        } else {
            permissionLauncher.launch(perm)
        }
    }

    private fun showEmpty(res: Int) {
        empty.setText(res)
        empty.visibility = View.VISIBLE
    }

    private fun loadVideos() {
        Thread {
            val out = mutableListOf<VideoItem>()
            val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val proj = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.SIZE
            )
            contentResolver.query(base, proj, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")
                ?.use { c ->
                    while (c.moveToNext()) {
                        out += VideoItem(
                            ContentUris.withAppendedId(base, c.getLong(0)),
                            c.getString(1) ?: "Video",
                            c.getLong(2),
                            c.getLong(3)
                        )
                    }
                }
            runOnUiThread {
                videos.clear()
                videos.addAll(out)
                videoAdapter.notifyDataSetChanged()
                if (out.isEmpty()) showEmpty(R.string.empty) else empty.visibility = View.GONE
            }
        }.start()
    }

    private fun open(uri: Uri) {
        if (uri.scheme == "content") {
            runCatching {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        startActivity(
            Intent(this, PlayerActivity::class.java)
                .setData(uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    }

    private fun askUrl() {
        val et = EditText(this).apply {
            hint = "https://example.com/video.mp4"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        val box = FrameLayout(this).apply {
            setPadding(48, 16, 48, 0)
            addView(et)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.open_url)
            .setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val u = et.text.toString().trim()
                if (u.isNotEmpty()) open(Uri.parse(u))
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}

class VideoAdapter(
    private val items: List<VideoItem>,
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<VideoAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val name: TextView = v.findViewById(R.id.name)
        val meta: TextView = v.findViewById(R.id.meta)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_video, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val v = items[position]
        h.name.text = v.title
        h.meta.text = "${fmt(v.durationMs)}  •  ${Formatter.formatShortFileSize(h.itemView.context, v.size)}"
        Glide.with(h.thumb).load(v.uri).centerCrop().into(h.thumb)
        h.itemView.setOnClickListener { onClick(h.bindingAdapterPosition) }
    }
}
