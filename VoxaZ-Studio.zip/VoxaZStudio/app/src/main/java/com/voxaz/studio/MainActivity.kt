package com.voxaz.studio

import android.Manifest
import android.app.PictureInPictureParams
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.InputType
import android.text.format.Formatter
import android.util.Rational
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.widget.doAfterTextChanged
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import kotlin.math.abs
import kotlin.math.roundToInt

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    private enum class Section { LIBRARY, PLAYLIST, FOLDERS, FAVORITES, HISTORY }

    private lateinit var store: Store
    private lateinit var audio: AudioManager
    private lateinit var videoAdapter: VideoAdapter
    private lateinit var folderAdapter: FolderAdapter
    private lateinit var queueAdapter: QueueAdapter
    private val handler = Handler(Looper.getMainLooper())

    // ---- views ----
    private val sidebar: View by lazy { findViewById(R.id.sidebar) }
    private val miniCard: View by lazy { findViewById(R.id.miniCard) }
    private val miniThumb: ImageView by lazy { findViewById(R.id.miniThumb) }
    private val miniName: TextView by lazy { findViewById(R.id.miniName) }
    private val miniMeta: TextView by lazy { findViewById(R.id.miniMeta) }
    private val libraryPane: View by lazy { findViewById(R.id.libraryPane) }
    private val playerPane: View by lazy { findViewById(R.id.playerPane) }
    private val sectionTitle: TextView by lazy { findViewById(R.id.sectionTitle) }
    private val search: EditText by lazy { findViewById(R.id.search) }
    private val btnGrid: ImageView by lazy { findViewById(R.id.btnGrid) }
    private val btnList: ImageView by lazy { findViewById(R.id.btnList) }
    private val recycler: RecyclerView by lazy { findViewById(R.id.list) }
    private val emptyView: TextView by lazy { findViewById(R.id.empty) }
    private val topBar: View by lazy { findViewById(R.id.topBar) }
    private val tvTitle: TextView by lazy { findViewById(R.id.tvTitle) }
    private val btnAspect: TextView by lazy { findViewById(R.id.btnAspect) }
    private val playerView: PlayerView by lazy { findViewById(R.id.player) }
    private val info: TextView by lazy { findViewById(R.id.info) }
    private val controls: View by lazy { findViewById(R.id.controls) }
    private val tvPos: TextView by lazy { findViewById(R.id.tvPos) }
    private val tvDur: TextView by lazy { findViewById(R.id.tvDur) }
    private val seekBar: SeekBar by lazy { findViewById(R.id.seek) }
    private val volSeek: SeekBar by lazy { findViewById(R.id.volSeek) }
    private val btnPlay: ImageView by lazy { findViewById(R.id.btnPlay) }
    private val btnSpeed: TextView by lazy { findViewById(R.id.btnSpeed) }
    private val btnLock: View by lazy { findViewById(R.id.btnLock) }
    private val btnUnlock: View by lazy { findViewById(R.id.btnUnlock) }
    private val queuePanel: View by lazy { findViewById(R.id.queuePanel) }
    private val queueList: RecyclerView by lazy { findViewById(R.id.queueList) }

    private val navItems: Map<Section, TextView> by lazy {
        mapOf(
            Section.LIBRARY to findViewById<TextView>(R.id.navLibrary),
            Section.PLAYLIST to findViewById<TextView>(R.id.navPlaylist),
            Section.FOLDERS to findViewById<TextView>(R.id.navFolders),
            Section.FAVORITES to findViewById<TextView>(R.id.navFavorites),
            Section.HISTORY to findViewById<TextView>(R.id.navHistory)
        )
    }

    // ---- state ----
    private val allVideos = mutableListOf<VideoItem>()
    private var shown: List<VideoItem> = emptyList()
    private var section = Section.LIBRARY
    private var folderFilter: String? = null
    private var gridMode = true
    private var query = ""
    private var denied = false

    private var queue: List<VideoItem> = emptyList()
    private var queueIndex = 0
    private var player: ExoPlayer? = null
    private var playerShown = false
    private var fullscreen = false
    private var inPip = false
    private var locked = false
    private var controlsShown = true
    private var queueShown = true
    private var seeking = false
    private var speedIdx = 2
    private var resizeIdx = 0
    private val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    )
    private val resizeNames = arrayOf("FIT", "FILL", "ZOOM")

    private val hideInfo = Runnable { info.visibility = View.GONE }
    private val hideControls = Runnable {
        if (fullscreen && !seeking) {
            controlsShown = false
            applyLayout()
        }
    }
    private val ticker = object : Runnable {
        override fun run() {
            val p = player
            if (p != null) {
                val dur = p.duration
                val pos = p.currentPosition
                if (!seeking) tvPos.text = fmt(pos)
                if (dur > 0) {
                    tvDur.text = fmt(dur)
                    if (!seeking) seekBar.progress = (pos * 1000 / dur).toInt()
                }
                seekBar.secondaryProgress = p.bufferedPercentage * 10
            }
            handler.postDelayed(this, 500)
        }
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) loadVideos() else {
                denied = true
                refreshList()
            }
        }

    private val pickLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) playUri(uri)
        }

    private val playerListener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val p = player
            if (p != null) onItemChanged(p.currentMediaItemIndex)
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            btnPlay.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
            if (isPlaying) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                scheduleHideControls()
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            updateMini()
        }

        override fun onPlayerError(error: PlaybackException) {
            Toast.makeText(
                this@MainActivity,
                getString(R.string.play_error, error.errorCodeName),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    // =====================================================================
    // Lifecycle
    // =====================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = Store(this)
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        queueShown = resources.configuration.screenWidthDp >= 900

        setupNav()
        setupLibrary()
        setupPlayerUi()
        setupGestures()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                handleBack()
            }
        })

        showSection(Section.LIBRARY)
        requestAndLoad()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        if (playerShown) initPlayer()
    }

    override fun onStop() {
        super.onStop()
        releasePlayer()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (playerShown && player?.isPlaying == true && !locked) enterPip()
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean, newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        applyLayout()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun hideSystemBars() {
        WindowInsetsControllerCompat(window, window.decorView).run {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun handleBack() {
        when {
            locked -> {}
            fullscreen -> setFullscreen(false)
            playerShown -> closePlayerPane()
            section == Section.FOLDERS && folderFilter != null -> {
                folderFilter = null
                refreshList()
            }
            else -> finish()
        }
    }

    private fun handleIntent(i: Intent?) {
        val d = i?.data ?: return
        if (i?.action != Intent.ACTION_VIEW) return
        playUri(d)
    }

    // =====================================================================
    // Library
    // =====================================================================

    private fun setupNav() {
        navItems.forEach { (sec, tv) ->
            tv.setOnClickListener {
                folderFilter = null
                showSection(sec)
            }
        }
        miniCard.setOnClickListener { reopenPlayer() }
    }

    private fun setupLibrary() {
        videoAdapter = VideoAdapter(
            onClick = { _, pos -> playQueue(shown, pos) },
            onLong = { item, anchor -> showItemMenu(item, anchor) }
        )
        folderAdapter = FolderAdapter { name ->
            folderFilter = name
            refreshList()
        }
        search.doAfterTextChanged {
            query = it?.toString() ?: ""
            refreshList()
        }
        btnGrid.setOnClickListener {
            gridMode = true
            refreshList()
        }
        btnList.setOnClickListener {
            gridMode = false
            refreshList()
        }
        findViewById<View>(R.id.btnFile).setOnClickListener {
            pickLauncher.launch(arrayOf("video/*"))
        }
        findViewById<View>(R.id.btnUrl).setOnClickListener { askUrl() }
    }

    private fun showSection(sec: Section) {
        section = sec
        val muted = ContextCompat.getColor(this, R.color.muted)
        navItems.forEach { (s, tv) ->
            val sel = s == sec
            tv.setBackgroundResource(if (sel) R.drawable.bg_nav_selected else 0)
            tv.setTextColor(if (sel) Color.WHITE else muted)
            tv.compoundDrawableTintList = ColorStateList.valueOf(if (sel) Color.WHITE else muted)
        }
        closePlayerPane()
        refreshList()
    }

    private fun spanCount(): Int {
        val contentDp = resources.configuration.screenWidthDp - 168 - 24
        return (contentDp / 160).coerceAtLeast(2)
    }

    private fun refreshList() {
        val q = query.trim().lowercase()
        val byUri = allVideos.associateBy { it.uri.toString() }
        var title = "Videos"
        var showFolders = false
        val base: List<VideoItem> = when (section) {
            Section.LIBRARY -> allVideos
            Section.PLAYLIST -> {
                title = "Playlist"
                store.playlist().mapNotNull { byUri[it] }
            }
            Section.FAVORITES -> {
                title = "Favorites"
                store.favorites().mapNotNull { byUri[it] }
            }
            Section.HISTORY -> {
                title = "History"
                store.history().mapNotNull { byUri[it] }
            }
            Section.FOLDERS -> {
                val f = folderFilter
                if (f == null) {
                    title = "Folders"
                    showFolders = true
                    emptyList<VideoItem>()
                } else {
                    title = "‹  $f"
                    allVideos.filter { it.folder == f }
                }
            }
        }
        val list = base.filter { q.isEmpty() || it.title.lowercase().contains(q) }
        shown = list
        sectionTitle.text = title

        if (showFolders) {
            val groups = allVideos.groupBy { it.folder }
                .map { Pair(it.key, it.value.size) }
                .filter { q.isEmpty() || it.first.lowercase().contains(q) }
                .sortedBy { it.first.lowercase() }
            folderAdapter.items = groups
            recycler.layoutManager = LinearLayoutManager(this)
            recycler.adapter = folderAdapter
            folderAdapter.notifyDataSetChanged()
            setEmpty(groups.isEmpty())
        } else {
            recycler.layoutManager =
                if (gridMode) GridLayoutManager(this, spanCount()) else LinearLayoutManager(this)
            recycler.adapter = videoAdapter
            videoAdapter.submit(list, gridMode)
            setEmpty(list.isEmpty())
        }

        val accent = ContextCompat.getColor(this, R.color.accent)
        val muted = ContextCompat.getColor(this, R.color.muted)
        btnGrid.setColorFilter(if (gridMode) accent else muted)
        btnList.setColorFilter(if (gridMode) muted else accent)
    }

    private fun setEmpty(isEmpty: Boolean) {
        if (isEmpty) {
            val res = when {
                denied -> R.string.no_permission
                section == Section.LIBRARY || section == Section.FOLDERS -> R.string.empty
                else -> R.string.nothing
            }
            emptyView.setText(res)
        }
        emptyView.visibility = if (isEmpty) View.VISIBLE else View.GONE
    }

    private fun showItemMenu(item: VideoItem, anchor: View) {
        val u = item.uri.toString()
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, if (store.isFav(u)) "Remove from favorites" else "Add to favorites")
        pm.menu.add(0, 2, 1, if (store.inPlaylist(u)) "Remove from playlist" else "Add to playlist")
        pm.setOnMenuItemClickListener { m ->
            when (m.itemId) {
                1 -> store.toggleFav(u)
                2 -> store.togglePlaylist(u)
            }
            refreshList()
            true
        }
        pm.show()
    }

    private fun requestAndLoad() {
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED) {
            loadVideos()
        } else {
            permissionLauncher.launch(perm)
        }
    }

    private fun loadVideos() {
        Thread {
            val out = mutableListOf<VideoItem>()
            val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val proj = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media.BUCKET_DISPLAY_NAME
            )
            contentResolver.query(base, proj, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")
                ?.use { c ->
                    while (c.moveToNext()) {
                        out.add(
                            VideoItem(
                                ContentUris.withAppendedId(base, c.getLong(0)),
                                c.getString(1) ?: "Video",
                                c.getLong(2),
                                c.getLong(3),
                                c.getString(4) ?: "Other"
                            )
                        )
                    }
                }
            runOnUiThread {
                denied = false
                allVideos.clear()
                allVideos.addAll(out)
                refreshList()
            }
        }.start()
    }

    private fun askUrl() {
        val et = EditText(this).apply {
            hint = "https://example.com/video.mp4"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        val box = FrameLayout(this).apply {
            setPadding(48, 16, 48, 0)
            addView(et)
        }
        AlertDialog.Builder(this)
            .setTitle("Stream URL")
            .setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val u = et.text.toString().trim()
                if (u.isNotEmpty()) playUri(Uri.parse(u))
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun nameOf(u: Uri): String {
        var n: String? = null
        if (u.scheme == "content") {
            runCatching {
                contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { if (it.moveToFirst()) n = it.getString(0) }
            }
        }
        return n ?: u.lastPathSegment ?: "Video"
    }

    // =====================================================================
    // Playback
    // =====================================================================

    private fun playUri(uri: Uri) {
        if (uri.scheme == "content") {
            runCatching {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        playQueue(listOf(VideoItem(uri, nameOf(uri))), 0)
    }

    private fun playQueue(list: List<VideoItem>, index: Int) {
        if (list.isEmpty()) return
        releasePlayer()
        queue = list
        queueIndex = index.coerceIn(0, list.size - 1)
        queueAdapter.items = queue
        queueAdapter.current = queueIndex
        queueAdapter.notifyDataSetChanged()
        playerShown = true
        initPlayer()
        applyLayout()
    }

    private fun reopenPlayer() {
        if (queue.isEmpty()) return
        playerShown = true
        initPlayer()
        player?.play()
        applyLayout()
    }

    private fun closePlayerPane() {
        if (playerShown) player?.pause()
        playerShown = false
        fullscreen = false
        locked = false
        applyLayout()
    }

    private fun initPlayer() {
        if (queue.isEmpty() || player != null) return
        val p = ExoPlayer.Builder(this)
            .setHandleAudioBecomingNoisy(true)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            .build()
        val media = queue.map {
            MediaItem.Builder()
                .setUri(it.uri)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(it.title).build())
                .build()
        }
        p.setMediaItems(media, queueIndex, store.getPos(queue[queueIndex].uri.toString()))
        p.addListener(playerListener)
        p.setPlaybackSpeed(speeds[speedIdx])
        p.prepare()
        p.playWhenReady = true
        playerView.player = p
        player = p
        onItemChanged(queueIndex)
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    private fun releasePlayer() {
        handler.removeCallbacks(ticker)
        val p = player ?: return
        val uri = p.currentMediaItem?.localConfiguration?.uri
        if (uri != null) {
            val pos = if (p.playbackState == Player.STATE_ENDED) 0L else p.currentPosition
            store.setPos(uri.toString(), pos)
        }
        queueIndex = p.currentMediaItemIndex.coerceAtLeast(0)
        p.release()
        player = null
        playerView.player = null
    }

    private fun onItemChanged(i: Int) {
        queueIndex = i
        val item = queue.getOrNull(i) ?: return
        tvTitle.text = item.title
        store.addHistory(item.uri.toString())
        queueAdapter.current = i
        queueAdapter.notifyDataSetChanged()
        queueList.scrollToPosition(i)
        updateMini()
    }

    private fun updateMini() {
        val item = queue.getOrNull(queueIndex)
        if (item == null) {
            miniCard.visibility = View.GONE
            return
        }
        miniCard.visibility = View.VISIBLE
        miniName.text = item.title
        val vs = player?.videoSize
        var res = ""
        if (vs != null && vs.width > 0 && vs.height > 0) {
            val tag = when {
                vs.height >= 2160 -> "  ·  4K"
                vs.height >= 1440 -> "  ·  2K"
                vs.height >= 1080 -> "  ·  FHD"
                vs.height >= 720 -> "  ·  HD"
                else -> ""
            }
            res = "${vs.width} x ${vs.height}$tag"
        }
        val size = if (item.size > 0) Formatter.formatShortFileSize(this, item.size) else ""
        miniMeta.text = listOf(res, size).filter { it.isNotEmpty() }.joinToString("  ·  ")
        Glide.with(miniThumb).load(item.uri).centerCrop().into(miniThumb)
    }

    // =====================================================================
    // Player UI
    // =====================================================================

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun applyLayout() {
        val full = playerShown && (fullscreen || inPip)
        libraryPane.visibility = if (playerShown) View.GONE else View.VISIBLE
        playerPane.visibility = if (playerShown) View.VISIBLE else View.GONE
        sidebar.visibility = if (full) View.GONE else View.VISIBLE
        topBar.visibility = if (full) View.GONE else View.VISIBLE

        val showQueue = queueShown && !full
        queuePanel.visibility = if (showQueue) View.VISIBLE else View.GONE
        volSeek.visibility =
            if (showQueue && resources.configuration.screenWidthDp < 1000) View.GONE else View.VISIBLE

        val ctlVisible = when {
            !playerShown || inPip || locked -> false
            fullscreen -> controlsShown
            else -> true
        }
        controls.visibility = if (ctlVisible) View.VISIBLE else View.GONE
        controls.setBackgroundResource(if (full) R.drawable.bg_controls_overlay else R.drawable.bg_controls_solid)
        btnLock.visibility =
            if (fullscreen && controlsShown && !locked && !inPip) View.VISIBLE else View.GONE
        btnUnlock.visibility = if (locked) View.VISIBLE else View.GONE

        val lp = playerView.layoutParams as FrameLayout.LayoutParams
        lp.bottomMargin = if (full || locked) 0 else dp(104)
        playerView.layoutParams = lp
    }

    private fun setFullscreen(on: Boolean) {
        fullscreen = on
        controlsShown = true
        applyLayout()
        scheduleHideControls()
    }

    private fun scheduleHideControls() {
        handler.removeCallbacks(hideControls)
        if (fullscreen && controlsShown) handler.postDelayed(hideControls, 3500)
    }

    private fun showInfo(text: String, sticky: Boolean = false) {
        info.text = text
        info.visibility = View.VISIBLE
        handler.removeCallbacks(hideInfo)
        if (!sticky) handler.postDelayed(hideInfo, 800)
    }

    private fun seekBy(deltaMs: Long) {
        val p = player ?: return
        val t = p.currentPosition + deltaMs
        val dur = p.duration
        p.seekTo(if (dur > 0) t.coerceIn(0L, dur) else t.coerceAtLeast(0L))
        showInfo(if (deltaMs < 0) "⏪ ${abs(deltaMs) / 1000}s" else "+${deltaMs / 1000}s ⏩")
        scheduleHideControls()
    }

    private fun setupPlayerUi() {
        queueAdapter = QueueAdapter { index -> player?.seekTo(index, 0L) }
        queueList.layoutManager = LinearLayoutManager(this)
        queueList.adapter = queueAdapter

        findViewById<View>(R.id.btnBack).setOnClickListener { handleBack() }
        findViewById<View>(R.id.btnQueue).setOnClickListener {
            queueShown = !queueShown
            applyLayout()
        }
        btnAspect.setOnClickListener {
            resizeIdx = (resizeIdx + 1) % resizeModes.size
            playerView.resizeMode = resizeModes[resizeIdx]
            btnAspect.text = resizeNames[resizeIdx]
            showInfo(resizeNames[resizeIdx])
        }

        btnPlay.setOnClickListener {
            val p = player
            if (p != null) {
                if (p.isPlaying) {
                    p.pause()
                } else {
                    if (p.playbackState == Player.STATE_ENDED) p.seekTo(0L)
                    p.play()
                }
            }
            scheduleHideControls()
        }
        findViewById<View>(R.id.btnPrev).setOnClickListener {
            val p = player
            if (p != null) {
                if (p.hasPreviousMediaItem()) p.seekToPreviousMediaItem() else p.seekTo(0L)
            }
        }
        findViewById<View>(R.id.btnNext).setOnClickListener {
            val p = player
            if (p != null && p.hasNextMediaItem()) p.seekToNextMediaItem()
        }
        findViewById<View>(R.id.btnRew).setOnClickListener { seekBy(-10_000L) }
        findViewById<View>(R.id.btnFwd).setOnClickListener { seekBy(30_000L) }
        findViewById<View>(R.id.btnPip).setOnClickListener { enterPip() }
        findViewById<View>(R.id.btnFull).setOnClickListener { setFullscreen(!fullscreen) }
        findViewById<View>(R.id.btnCc).setOnClickListener { pickTrack(C.TRACK_TYPE_TEXT, "Subtitles") }
        findViewById<View>(R.id.btnAudio).setOnClickListener { pickTrack(C.TRACK_TYPE_AUDIO, "Audio") }
        btnSpeed.setOnClickListener {
            speedIdx = (speedIdx + 1) % speeds.size
            val s = speeds[speedIdx]
            player?.setPlaybackSpeed(s)
            btnSpeed.text = if (s == s.toInt().toFloat()) "${s.toInt()}.0x" else "${s}x"
            scheduleHideControls()
        }
        btnLock.setOnClickListener { setLocked(true) }
        btnUnlock.setOnClickListener { setLocked(false) }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val d = player?.duration ?: 0L
                    if (d > 0) tvPos.text = fmt(d * progress / 1000)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                seeking = true
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                seeking = false
                val p = player
                val prog = seekBar?.progress ?: 0
                if (p != null && p.duration > 0) p.seekTo(p.duration * prog / 1000)
                scheduleHideControls()
            }
        })

        volSeek.max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        volSeek.progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        volSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) audio.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun setLocked(value: Boolean) {
        locked = value
        controlsShown = true
        applyLayout()
        if (!value) scheduleHideControls()
    }

    private fun pickTrack(type: Int, title: String) {
        val p = player ?: return
        val groups = p.currentTracks.groups.filter { it.type == type && it.isSupported }
        if (groups.isEmpty()) {
            Toast.makeText(this, "No $title tracks", Toast.LENGTH_SHORT).show()
            return
        }
        val names = ArrayList<String>()
        if (type == C.TRACK_TYPE_TEXT) names.add("Off")
        groups.forEachIndexed { i, g ->
            val f = g.getTrackFormat(0)
            names.add(f.label ?: f.language ?: "Track ${i + 1}")
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(names.toTypedArray()) { _, which ->
                val b = p.trackSelectionParameters.buildUpon()
                if (type == C.TRACK_TYPE_TEXT) {
                    if (which == 0) {
                        b.setTrackTypeDisabled(type, true)
                    } else {
                        b.setTrackTypeDisabled(type, false)
                        b.setOverrideForType(TrackSelectionOverride(groups[which - 1].mediaTrackGroup, 0))
                    }
                } else {
                    b.setOverrideForType(TrackSelectionOverride(groups[which].mediaTrackGroup, 0))
                }
                p.trackSelectionParameters = b.build()
            }
            .show()
    }

    private fun enterPip() {
        val p = player ?: return
        if (Build.VERSION.SDK_INT < 26 || !playerShown) return
        val vs = p.videoSize
        val r = if (vs.width > 0 && vs.height > 0) vs.width.toFloat() / vs.height else 16f / 9f
        val ratio = Rational((r.coerceIn(0.5f, 2.0f) * 1000).toInt(), 1000)
        runCatching {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(ratio).build())
        }
    }

    // =====================================================================
    // Gestures on the video surface
    // =====================================================================

    private fun setupGestures() {
        var mode = 0 // 0 none, 1 seek, 2 brightness, 3 volume
        var seekStart = 0L
        var seekOff = 0L
        var bright = 0.5f
        var vol = 0f
        var boosted = false
        val maxVol = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat()

        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                mode = 0
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked || !fullscreen) return true
                controlsShown = !controlsShown
                applyLayout()
                scheduleHideControls()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val p = player ?: return true
                if (locked) return true
                val w = playerView.width
                if (e.x < w / 3f) {
                    seekBy(-10_000L)
                } else if (e.x > w * 2 / 3f) {
                    seekBy(10_000L)
                } else {
                    p.playWhenReady = !p.playWhenReady
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (locked) return
                player?.setPlaybackSpeed(2f)
                boosted = true
                showInfo("2x ⏩", sticky = true)
            }

            override fun onScroll(
                e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float
            ): Boolean {
                if (locked || e1 == null || boosted) return false
                val p = player ?: return false
                if (mode == 0) {
                    mode = if (abs(distanceX) > abs(distanceY)) 1
                    else if (e1.x < playerView.width / 2f) 2
                    else 3
                    if (mode == 1) {
                        seekStart = p.currentPosition
                        seekOff = 0L
                    } else if (mode == 2) {
                        val b = window.attributes.screenBrightness
                        bright = if (b < 0f) 0.5f else b
                    } else {
                        vol = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
                    }
                }
                val h = playerView.height.coerceAtLeast(1).toFloat()
                if (mode == 1) {
                    seekOff -= (distanceX * 100).toLong()
                    val t = (seekStart + seekOff).coerceIn(0L, p.duration.coerceAtLeast(0L))
                    val sign = if (seekOff >= 0) "+" else "-"
                    showInfo("${fmt(t)}  (${sign}${abs(seekOff) / 1000}s)")
                } else if (mode == 2) {
                    bright = (bright + distanceY / h).coerceIn(0.02f, 1f)
                    val lp = window.attributes
                    lp.screenBrightness = bright
                    window.attributes = lp
                    showInfo("☀ ${(bright * 100).roundToInt()}%")
                } else {
                    vol = (vol + distanceY / h * maxVol * 1.5f).coerceIn(0f, maxVol)
                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, vol.roundToInt(), 0)
                    volSeek.progress = vol.roundToInt()
                    showInfo("🔊 ${(vol / maxVol * 100).roundToInt()}%")
                }
                return true
            }
        })

        playerView.setOnTouchListener { _, ev ->
            detector.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                val p = player
                if (p != null && mode == 1) {
                    p.seekTo((seekStart + seekOff).coerceIn(0L, p.duration.coerceAtLeast(0L)))
                }
                if (boosted) {
                    p?.setPlaybackSpeed(speeds[speedIdx])
                    boosted = false
                    handler.post(hideInfo)
                }
                mode = 0
            }
            true
        }
    }
}
