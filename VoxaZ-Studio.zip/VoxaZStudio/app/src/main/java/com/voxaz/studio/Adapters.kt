package com.voxaz.studio

import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

/** Library list (mode 0), grid (mode 1) and vertical shorts grid (mode 2). */
class VideoAdapter(
    private val onClick: (VideoItem, Int) -> Unit,
    private val onLong: (VideoItem, View) -> Unit
) : RecyclerView.Adapter<VideoAdapter.VH>() {

    private var items: List<VideoItem> = emptyList()
    private var mode = 1

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val name: TextView = v.findViewById(R.id.name)
        val meta: TextView = v.findViewById(R.id.meta)
    }

    fun submit(list: List<VideoItem>, newMode: Int) {
        items = list
        mode = newMode
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int = mode

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val res = when (viewType) {
            2 -> R.layout.item_short
            1 -> R.layout.item_video_grid
            else -> R.layout.item_video_list
        }
        return VH(LayoutInflater.from(parent.context).inflate(res, parent, false))
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val v = items[position]
        h.name.text = v.title
        val size = if (v.size > 0) "  •  " + Formatter.formatShortFileSize(h.itemView.context, v.size) else ""
        h.meta.text = fmt(v.durationMs) + size
        val req = Glide.with(h.thumb).load(v.uri).centerCrop().dontAnimate()
        when (mode) {
            2 -> req.override(270, 480).into(h.thumb)
            1 -> req.override(400, 225).into(h.thumb)
            else -> req.override(240, 135).into(h.thumb)
        }
        h.itemView.setOnClickListener { onClick(v, h.bindingAdapterPosition) }
        h.itemView.setOnLongClickListener {
            onLong(v, h.itemView)
            true
        }
    }
}

/** Folder list (name, video count). */
class FolderAdapter(private val onClick: (String) -> Unit) : RecyclerView.Adapter<FolderAdapter.VH>() {

    var items: List<Pair<String, Int>> = emptyList()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.name)
        val meta: TextView = v.findViewById(R.id.meta)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_folder, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val p = items[position]
        h.name.text = p.first
        h.meta.text = "${p.second} videos"
        h.itemView.setOnClickListener { onClick(p.first) }
    }
}

/** "Now Playing" queue. */
class QueueAdapter(private val onClick: (Int) -> Unit) : RecyclerView.Adapter<QueueAdapter.VH>() {

    var items: List<VideoItem> = emptyList()
    var current = -1

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val name: TextView = v.findViewById(R.id.name)
        val meta: TextView = v.findViewById(R.id.meta)
        val playing: TextView = v.findViewById(R.id.playing)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_queue, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val v = items[position]
        val isCurrent = position == current
        h.name.text = v.title
        h.meta.text = fmt(v.durationMs)
        h.playing.visibility = if (isCurrent) View.VISIBLE else View.GONE
        h.itemView.setBackgroundResource(if (isCurrent) R.drawable.bg_queue_current else 0)
        Glide.with(h.thumb).load(v.uri).centerCrop().dontAnimate().override(160, 90).into(h.thumb)
        h.itemView.setOnClickListener { onClick(h.bindingAdapterPosition) }
    }
}
