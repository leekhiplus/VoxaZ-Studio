package com.voxaz.studio

import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.graphics.Color
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.media3.common.Player
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

/** Library list (mode 0), grid (mode 1) and vertical shorts grid (mode 2). */
class VideoAdapter(
    private val onClick: (VideoItem, Int) -> Unit,
    private val onLong: (VideoItem, View) -> Unit
) : RecyclerView.Adapter<VideoAdapter.VH>() {

    private var items: List<VideoItem> = emptyList()
    private var mode = 1

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val name: TextView = v.findViewById(R.id.name)
        val meta: TextView = v.findViewById(R.id.meta)
    }

    fun submit(list: List<VideoItem>, newMode: Int) {
        items = list
        mode = newMode
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int = mode

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val res = when (viewType) {
            2 -> R.layout.item_short
            1 -> R.layout.item_video_grid
            else -> R.layout.item_video_list
        }
        return VH(LayoutInflater.from(parent.context).inflate(res, parent, false))
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val v = items[position]
        h.name.text = v.title
        val size = if (v.size > 0) "  •  " + Formatter.formatShortFileSize(h.itemView.context, v.size) else ""
        h.meta.text = fmt(v.durationMs) + size
        val req = Glide.with(h.thumb).load(v.uri).centerCrop().dontAnimate()
        when (mode) {
            2 -> req.override(270, 480).into(h.thumb)
            1 -> req.override(400, 225).into(h.thumb)
            else -> req.override(240, 135).into(h.thumb)
        }
        h.itemView.setOnClickListener { onClick(v, h.bindingAdapterPosition) }
        h.itemView.setOnLongClickListener {
            onLong(v, h.itemView)
            true
        }
    }
}

/** Folder list (name, video count). */
class FolderAdapter(private val onClick: (String) -> Unit) : RecyclerView.Adapter<FolderAdapter.VH>() {

    var items: List<Pair<String, Int>> = emptyList()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.name)
        val meta: TextView = v.findViewById(R.id.meta)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_folder, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val p = items[position]
        h.name.text = p.first
        h.meta.text = "${p.second} videos"
        h.itemView.setOnClickListener { onClick(p.first) }
    }
}

/** "Now Playing" queue. */
class QueueAdapter(private val onClick: (Int) -> Unit) : RecyclerView.Adapter<QueueAdapter.VH>() {

    var items: List<VideoItem> = emptyList()
    var current = -1

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val name: TextView = v.findViewById(R.id.name)
        val meta: TextView = v.findViewById(R.id.meta)
        val playing: TextView = v.findViewById(R.id.playing)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_queue, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val v = items[position]
        val isCurrent = position == current
        h.name.text = v.title
        h.meta.text = fmt(v.durationMs)
        h.playing.visibility = if (isCurrent) View.VISIBLE else View.GONE
        h.itemView.setBackgroundResource(if (isCurrent) R.drawable.bg_queue_current else 0)
        Glide.with(h.thumb).load(v.uri).centerCrop().dontAnimate().override(160, 90).into(h.thumb)
        h.itemView.setOnClickListener { onClick(h.bindingAdapterPosition) }
    }
}

/** TikTok-style vertical feed: one full-screen page per short; one shared player. */
class ShortsAdapter(
    private val onTap: () -> Unit,
    private val onFav: (VideoItem) -> Boolean,
    private val isFav: (VideoItem) -> Boolean
) : RecyclerView.Adapter<ShortsAdapter.VH>() {

    var items: List<VideoItem> = emptyList()
    var player: Player? = null
    var fx: ((PlayerView) -> Unit)? = null
    private var activePos = -1
    private var firstFrame = false
    private val attached = HashMap<Int, VH>()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val playerView: PlayerView = v.findViewById(R.id.shortPlayer)
        val thumb: ImageView = v.findViewById(R.id.shortThumb)
        val title: TextView = v.findViewById(R.id.shortTitle)
        val heart: ImageView = v.findViewById(R.id.shortHeart)
        val progress: ProgressBar = v.findViewById(R.id.shortProgress)
        val pauseIcon: ImageView = v.findViewById(R.id.shortPause)
    }

    private fun heartColor(fav: Boolean): Int = if (fav) Color.parseColor("#FF4D6D") else Color.WHITE

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_short_page, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val v = items[position]
        h.title.text = v.title
        h.thumb.visibility = if (position == activePos && firstFrame) View.GONE else View.VISIBLE
        h.pauseIcon.visibility = View.GONE
        h.progress.progress = 0
        h.heart.setColorFilter(heartColor(isFav(v)))
        h.heart.setOnClickListener {
            h.heart.setColorFilter(heartColor(onFav(v)))
        }
        h.itemView.setOnClickListener { onTap() }
        Glide.with(h.thumb).load(v.uri).dontAnimate().override(540, 960).into(h.thumb)
    }

    override fun onViewAttachedToWindow(holder: VH) {
        super.onViewAttachedToWindow(holder)
        val pos = holder.bindingAdapterPosition
        attached[pos] = holder
        if (pos == activePos) attachPlayer(holder)
    }

    override fun onViewDetachedFromWindow(holder: VH) {
        holder.playerView.player = null
        attached.entries.removeAll { it.value === holder }
        super.onViewDetachedFromWindow(holder)
    }

    private fun attachPlayer(h: VH) {
        h.playerView.player = null
        h.playerView.player = player
        fx?.invoke(h.playerView)
    }

    /** Make [pos] the page that owns the player. */
    fun setActive(pos: Int) {
        attached[activePos]?.let {
            it.playerView.player = null
            it.thumb.visibility = View.VISIBLE
        }
        activePos = pos
        firstFrame = false
        attached[pos]?.let {
            it.thumb.visibility = View.VISIBLE
            it.pauseIcon.visibility = View.GONE
            it.progress.progress = 0
            attachPlayer(it)
        }
    }

    fun onFirstFrame() {
        firstFrame = true
        attached[activePos]?.thumb?.visibility = View.GONE
    }

    fun setProgress(permille: Int) {
        attached[activePos]?.progress?.progress = permille
    }

    fun setPaused(paused: Boolean) {
        attached[activePos]?.pauseIcon?.visibility = if (paused) View.VISIBLE else View.GONE
    }

    fun refreshFx() {
        attached[activePos]?.let { fx?.invoke(it.playerView) }
    }

    fun detachAll() {
        attached.values.forEach { it.playerView.player = null }
    }

    /** Forget holders of a discarded view tree (rotation). */
    fun reset() {
        detachAll()
        attached.clear()
    }
}
