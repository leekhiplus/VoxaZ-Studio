package com.voxaz.studio

import android.app.PictureInPictureParams
import android.content.res.Configuration
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.net.Uri
import android.util.Rational
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlin.math.abs
import kotlin.math.roundToInt

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var info: TextView
    private lateinit var topBar: View
    private lateinit var tvTitle: TextView
    private lateinit var btnAspect: TextView
    private lateinit var btnUnlock: View
    private lateinit var audio: AudioManager

    private val handler = Handler(Looper.getMainLooper())
    private val hideInfo = Runnable { info.visibility = View.GONE }
    private val prefs by lazy { getSharedPreferences("voxaz", MODE_PRIVATE) }

    private var items: List<VideoItem> = emptyList()
    private var startIndex = 0
    private var locked = false
    private var resizeIdx = 0
    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    )
    private val resizeNames = arrayOf("FIT", "FILL", "ZOOM")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        audio = getSystemService(AUDIO_SERVICE) as AudioManager

        playerView = findViewById(R.id.player)
        info = findViewById(R.id.info)
        topBar = findViewById(R.id.topBar)
        tvTitle = findViewById(R.id.tvTitle)
        btnAspect = findViewById(R.id.btnAspect)
        btnUnlock = findViewById(R.id.btnUnlock)

        val data = intent.data
        if (data != null) {
            items = listOf(VideoItem(data, nameOf(data)))
        } else {
            items = Playlist.items
            startIndex = intent.getIntExtra("index", 0).coerceIn(0, (items.size - 1).coerceAtLeast(0))
        }
        if (items.isEmpty()) {
            finish()
            return
        }

        playerView.setControllerVisibilityListener(
            PlayerView.ControllerVisibilityListener { v -> if (!locked) topBar.visibility = v }
        )
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        btnAspect.setOnClickListener {
            resizeIdx = (resizeIdx + 1) % resizeModes.size
            playerView.resizeMode = resizeModes[resizeIdx]
            btnAspect.text = resizeNames[resizeIdx]
            showInfo(resizeNames[resizeIdx])
        }
        findViewById<View>(R.id.btnRotate).setOnClickListener {
            requestedOrientation =
                if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE)
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        findViewById<View>(R.id.btnPip).setOnClickListener { enterPip() }
        findViewById<View>(R.id.btnLock).setOnClickListener { setLocked(true) }
        btnUnlock.setOnClickListener { setLocked(false) }

        setupGestures()
        hideSystemBars()
    }

    // ---------- Player lifecycle ----------

    override fun onStart() {
        super.onStart()
        initPlayer()
    }

    override fun onStop() {
        super.onStop()
        releasePlayer()
    }

    private fun initPlayer() {
        val p = ExoPlayer.Builder(this)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .setHandleAudioBecomingNoisy(true)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            .build()

        val media = items.map {
            MediaItem.Builder()
                .setUri(it.uri)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(it.title).build())
                .build()
        }
        val resume = prefs.getLong("pos_${items[startIndex].uri}", 0L)
        p.setMediaItems(media, startIndex, resume)
        p.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                tvTitle.text = mediaItem?.mediaMetadata?.title ?: ""
            }

            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(
                    this@PlayerActivity,
                    getString(R.string.play_error, error.errorCodeName),
                    Toast.LENGTH_LONG
                ).show()
            }
        })
        p.prepare()
        p.playWhenReady = true
        playerView.player = p
        player = p
        tvTitle.text = items[startIndex].title
    }

    private fun releasePlayer() {
        val p = player ?: return
        val uri = p.currentMediaItem?.localConfiguration?.uri
        if (uri != null) {
            val pos = if (p.playbackState == Player.STATE_ENDED) 0L else p.currentPosition
            prefs.edit().putLong("pos_$uri", pos).apply()
        }
        startIndex = p.currentMediaItemIndex.coerceAtLeast(0)
        p.release()
        player = null
        playerView.player = null
    }

    // ---------- Gestures ----------

    private fun setupGestures() {
        var mode = 0 // 0 none, 1 seek, 2 brightness, 3 volume
        var seekStart = 0L
        var seekOff = 0L
        var bright = 0.5f
        var vol = 0f
        var boosted = false
        val maxVol = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat()

        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                mode = 0
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) return true
                if (playerView.isControllerFullyVisible) playerView.hideController()
                else playerView.showController()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val p = player ?: return true
                if (locked) return true
                val w = playerView.width
                when {
                    e.x < w / 3f -> {
                        p.seekTo((p.currentPosition - 10_000).coerceAtLeast(0))
                        showInfo("⏪ -10s")
                    }
                    e.x > w * 2 / 3f -> {
                        val t = p.currentPosition + 10_000
                        p.seekTo(if (p.duration > 0) t.coerceAtMost(p.duration) else t)
                        showInfo("+10s ⏩")
                    }
                    else -> p.playWhenReady = !p.playWhenReady
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (locked) return
                player?.setPlaybackSpeed(2f)
                boosted = true
                showInfo("2x ⏩", sticky = true)
            }

            override fun onScroll(
                e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float
            ): Boolean {
                if (locked || e1 == null || boosted) return false
                val p = player ?: return false
                if (mode == 0) {
                    mode = when {
                        abs(distanceX) > abs(distanceY) -> 1
                        e1.x < playerView.width / 2f -> 2
                        else -> 3
                    }
                    when (mode) {
                        1 -> { seekStart = p.currentPosition; seekOff = 0 }
                        2 -> {
                            val b = window.attributes.screenBrightness
                            bright = if (b < 0) 0.5f else b
                        }
                        3 -> vol = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
                    }
                }
                val h = playerView.height.coerceAtLeast(1).toFloat()
                when (mode) {
                    1 -> {
                        seekOff -= (distanceX * 100).toLong()
                        val t = (seekStart + seekOff).coerceIn(0L, p.duration.coerceAtLeast(0L))
                        val sign = if (seekOff >= 0) "+" else "-"
                        showInfo("${fmt(t)}  ($sign${abs(seekOff) / 1000}s)")
                    }
                    2 -> {
                        bright = (bright + distanceY / h).coerceIn(0.02f, 1f)
                        val lp = window.attributes
                        lp.screenBrightness = bright
                        window.attributes = lp
                        showInfo("☀ ${(bright * 100).roundToInt()}%")
                    }
                    3 -> {
                        vol = (vol + distanceY / h * maxVol * 1.5f).coerceIn(0f, maxVol)
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, vol.roundToInt(), 0)
                        showInfo("🔊 ${(vol / maxVol * 100).roundToInt()}%")
                    }
                }
                return true
            }
        })

        playerView.setOnTouchListener { _, ev ->
            detector.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                val p = player
                if (p != null && mode == 1) {
                    p.seekTo((seekStart + seekOff).coerceIn(0L, p.duration.coerceAtLeast(0L)))
                }
                if (boosted) {
                    p?.setPlaybackSpeed(1f)
                    boosted = false
                    handler.post(hideInfo)
                }
                mode = 0
            }
            true
        }
    }

    private fun showInfo(text: String, sticky: Boolean = false) {
        info.text = text
        info.visibility = View.VISIBLE
        handler.removeCallbacks(hideInfo)
        if (!sticky) handler.postDelayed(hideInfo, 800)
    }

    // ---------- Lock / PiP / system UI ----------

    private fun setLocked(value: Boolean) {
        locked = value
        playerView.useController = !value
        topBar.visibility = if (value) View.GONE else View.VISIBLE
        btnUnlock.visibility = if (value) View.VISIBLE else View.GONE
        if (!value) playerView.showController()
    }

    private fun enterPip() {
        val p = player ?: return
        if (Build.VERSION.SDK_INT < 26) return
        val vs = p.videoSize
        val r = if (vs.width > 0 && vs.height > 0) vs.width.toFloat() / vs.height else 16f / 9f
        val ratio = Rational((r.coerceIn(0.5f, 2.0f) * 1000).toInt(), 1000)
        runCatching {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(ratio).build())
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (player?.isPlaying == true && !locked) enterPip()
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean, newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            playerView.useController = false
            topBar.visibility = View.GONE
        } else if (!locked) {
            playerView.useController = true
            playerView.showController()
        }
    }

    private fun hideSystemBars() {
        WindowInsetsControllerCompat(window, window.decorView).run {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun nameOf(u: Uri): String {
        var n: String? = null
        if (u.scheme == "content") {
            runCatching {
                contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { if (it.moveToFirst()) n = it.getString(0) }
            }
        }
        return n ?: u.lastPathSegment ?: "Video"
    }
}
