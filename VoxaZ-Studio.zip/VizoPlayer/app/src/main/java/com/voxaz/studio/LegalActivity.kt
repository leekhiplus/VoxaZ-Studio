package com.voxaz.studio

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/** Shows the About, Privacy Policy, Terms and Licenses pages from assets/legal. */
class LegalActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_legal)

        val root = findViewById<View>(R.id.legalRoot)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        findViewById<View>(R.id.legalBack).setOnClickListener { finish() }

        val page = intent.getStringExtra("page") ?: "about"
        val title = when (page) {
            "privacy" -> "Privacy Policy"
            "terms" -> "Terms of Use"
            "licenses" -> "Open-source licenses"
            else -> "About"
        }
        val file = when (page) {
            "privacy", "terms", "licenses" -> page
            else -> "about"
        }
        findViewById<TextView>(R.id.legalTitle).text = title

        val web = findViewById<WebView>(R.id.legalWeb)
        web.setBackgroundColor(Color.parseColor("#0A0E1A"))
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, request.url)) }
                return true
            }
        }
        web.loadDataWithBaseURL("file:///android_asset/legal/", render(file), "text/html", "utf-8", null)
    }

    private fun render(name: String): String {
        val raw = assets.open("legal/$name.html").bufferedReader().use { it.readText() }
        val version = runCatching { packageManager.getPackageInfo(packageName, 0).versionName }
            .getOrNull() ?: "1.0.0"
        return raw
            .replace("{{DEVELOPER}}", getString(R.string.developer_name))
            .replace("{{EMAIL}}", getString(R.string.support_email))
            .replace("{{VERSION}}", version)
    }
}
