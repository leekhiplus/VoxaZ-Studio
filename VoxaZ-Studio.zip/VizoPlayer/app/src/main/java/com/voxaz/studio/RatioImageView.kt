package com.voxaz.studio

import android.content.Context
import android.util.AttributeSet
import android.view.View
import androidx.appcompat.widget.AppCompatImageView

/** ImageView whose height is width * thumbRatio (0.5625 = 16:9, 1.7778 = 9:16). */
class RatioImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : AppCompatImageView(context, attrs, defStyleAttr) {

    private var ratio = 0.5625f

    init {
        if (attrs != null) {
            val a = context.obtainStyledAttributes(attrs, R.styleable.RatioImageView)
            ratio = a.getFloat(R.styleable.RatioImageView_thumbRatio, ratio)
            a.recycle()
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = View.MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, (w * ratio).toInt())
    }
}
